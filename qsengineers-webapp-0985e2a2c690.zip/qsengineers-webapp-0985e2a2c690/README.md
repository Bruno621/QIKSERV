
# WebApp
This readme is about the Preoday webapp, with the usage commands.
This project was built using the AngularJS and now we are progressively migrating to React.
If you need to learn about the code, you can see the [angular.md](./docs/README-ANGULAR.md) or [react.md](./docs/README-REACT.md).

## Libs versions
* [angular](https://docs.angularjs.org/guide/component) v1.5.8
* [react](https://reactjs.org/blog/2017/09/26/react-v16.0.html) v16.8.6
* [Webpack](https://webpack.js.org/) v4.35.2

## Installation
To run locally you will need to install each of the below and possibly Ruby (for Compass).

* [node.js](https://nodejs.org/en/) v11.12.0
* [npm](https://www.npmjs.com/) v6.7.0
* [Sass](https://sass-lang.com/) & [Compass]

Once installed, go to the root of this repo (webapp) and run the following commands:
```sh
$ npm install webpack-cli -g
$ npm install
```

Then to start a local webpack web server:
```sh
$ npm run serve
```

### Scripts

All scripts are run with `npm run [script]`, for example: `npm run test`.

* `build` - will run the build and using local env and will keep the console.log
* `build-dev` - will run the build and using dev env and will keep the console.log
* `build-demo` - will run the build and using demo env and will keep the console.log
* `build-prod` - will run the build and using prod env and will keep the console.log
* `serve` - start development server with local configuration, try it by opening `http://localhost:8080/` or the browserSync version at `http://localhost:3000/``
* `test` - run all **angular** tests
* `test:react` - run all **react** tests
* `test:react:watch` - run all **react** tests and keep watching for file's changes to run again
* `npm run test:e2e` - will run all e2e tests in a chrome browser. See the section below to help setting this up
* `npm run test:e2e:handless` - will run all e2e tests in handless mode. See the section below to help setting this up


# To run the E2E tests in docker container with docker-compose
## On mac osx you need version 20.10.2 of the docker
* Make sure you have run: ```npm install``` (Tested on version v11.12.0 of nodeJs)
* Make sure you have run: ```npm rum build```
* At the root of the project create a folder with the name "artifacts"
* Inside the artifacts folder create a file with the name of "http_pass" and inside it put the user on a line and password below
* Inside the artifacts folder make a copy of the file "id_rsa"
* Make a copy of the "preo-proxy" project to the "artifacts" folder, and rename it to "DeployProxyDemo".
* At the root of the web-orders project, run: ```docker-compose up -d --build```
* In the terminal run:  ```docker ps``` and get the web container id
* In the terminal run:  ```docker exec -it {containerid} bash``` to enter the web-orders container. Replace `{containerid}` with the container you've in the step above
* Inside the container run: ```./web-orders/scripts/deployWebOrdersv2.sh dev```
* Inside the container run: ```apachectl start```
* Inside the image bash run the tests: ```npm run test:e2e:headless```

See what each script does by looking at the `scripts` section in [package.json](./package.json).
