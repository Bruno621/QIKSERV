
export default function routes($urlRouterProvider,$stateProvider){
  "ngInject";

  $stateProvider.state("app", {
    url: "",
  });

  $urlRouterProvider.otherwise(($injector, $location) => {
		const $state = $injector.get('$state');
		const $stateParams = $injector.get('$stateParams');

      $state.go('main.notFound', {
        entityId: $stateParams.entityId
      });

  });
}
