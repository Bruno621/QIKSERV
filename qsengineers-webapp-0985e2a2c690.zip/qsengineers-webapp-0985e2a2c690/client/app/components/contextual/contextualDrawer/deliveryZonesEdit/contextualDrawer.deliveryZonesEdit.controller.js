export default class ContextualDrawerDeliveryZonesEditController {
  static get UID(){
    return "ContextualDrawerDeliveryZonesEdit";
  }

  onCancel(){

    this.contextualDrawer.cancel();
    this.$rootScope.$broadcast('on-cancel-delivery-zone', this.editableDeliveryZone);
  }

  submit(){
    console.log("This delivery zone form ", this.deliveryZoneForm);
    if (this.deliveryZoneForm.$valid){
      this.DeliveryZoneService.saveEditableDeliveryZone()
        .then(()=>{
          this.DeliveryZoneService.clearEditingMode();
          this.$rootScope.$broadcast('on-finish-editing-delivery-zone', this.editableDeliveryZone);
          return this.contextualDrawer.close();
        }).then(()=>{
          console.log("close deliveryZonesEdit is done", this.deliveryZoneForm);
        });
      }
  }

  clearPolygon(){
    this.editableDeliveryZone.polygon = [];
  }

  constructor($scope, $rootScope, $stateParams, gettextCatalog, $mdSidenav, DeliveryZoneService, contextualDrawer, VenueService, StateService) {
    "ngInject";
    this.$rootScope = $rootScope;
    this.$mdSidenav = $mdSidenav;
    this.DeliveryZoneService=DeliveryZoneService;
    this.contextualDrawer=contextualDrawer;
    this.editableData = DeliveryZoneService.editableData;
    this.distanceUnit = VenueService.getKmOrMiles(StateService.venue);
    this.translatedDistanceUnit = "kms";

    if (this.distanceUnit === "kms") {
      this.translatedDistanceUnit = gettextCatalog.getString("kms");
    } else if (this.distanceUnit === "miles") {
      this.translatedDistanceUnit = gettextCatalog.getString("miles");
    }

    this.isEditing = false;

    $scope.$watch('drawerDeliveryZonesEditCtrl.DeliveryZoneService.editableDeliveryZone',(newValue,oldValue)=>{
      console.log("on watch ", newValue, oldValue);
      this.editableDeliveryZone = newValue;
    })

  }
}
