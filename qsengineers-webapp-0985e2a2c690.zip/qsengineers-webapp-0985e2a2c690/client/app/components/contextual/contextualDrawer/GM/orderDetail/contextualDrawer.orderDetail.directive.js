import controller from './contextualDrawer.orderDetail.controller'

export default function contextualMenu() {
  'ngInject';

  return {
    restrict: 'E',
    scope: {
      order: '=',
      payments: '=?'
    },
    bindToController: true,
    controller: controller.UID,
    controllerAs: 'drawerOrderDetailCtrl',
    template: require('./contextualDrawer.orderDetail.tpl.html')
  };
}
