export default class ContextualDrawerOrderDetailController {
  static get UID(){
    return 'ContextualDrawerOrderDetail';
  }

  close() {
    this.$window.history.back();
  }

  done() {
    const {$state, $stateParams} = this;

    if (this.isCustomersScreen()) {
      return $state.go('main.dashboard.customers.search', {
        value: $stateParams.value
      });
    }

    return $state.go('main.dashboard.orders', {
      value: $stateParams.value
    });
  }

  isCustomersScreen() {
    return this.$state.current.name.indexOf('main.dashboard.customers') > -1;
  }

  refundOrder() {
    const {$state, $stateParams, order} = this;

    $state.go('main.dashboard.orders.refund', {
      orderId: $stateParams.orderId,
      order: order
    });
  }

  amendOrder() {
    const {StateService, DialogService, LabelService, ErrorService, OperateService, Snack} = this;

    if (!StateService.getOperateUrl()) {
      return Snack.showError(ErrorService.REQUIRED_CHANNEL_OPERATOR_URL.message);
    }

    // Callback when tap `YES` in confirmation dialog
    function openNewTab() {
      OperateService.openNewTab();

      this.handleConfirmCancelOrder()
        .then(this.generateTokenAndGoToWeborders.bind(this))
        .catch(() => {
          OperateService.closeReorderTab();
        });
    }

    DialogService.confirm(LabelService.CONFIRMATION_TITLE, LabelService.CONTENT_AMEND_CUSTOMER_ORDER, {
      onConfirm: openNewTab.bind(this)
    });
  }

  cancelOrder() {
    if (!this.order) {
      return this.showError();
    }

    const {StateService, DialogService, LabelService, ErrorService, Snack} = this;

    if (this.isCustomersScreen() && !StateService.getOperateUrl()) {
      return Snack.showError(ErrorService.REQUIRED_CHANNEL_OPERATOR_URL.message);
    }

    DialogService.confirm(LabelService.CONFIRMATION_TITLE, LabelService.CONTENT_CANCEL_CUSTOMER_ORDER)
      .then(this.handleConfirmCancelOrder.bind(this));
  }

  handleConfirmCancelOrder() {
    const {$scope, $q, Spinner, gettextCatalog} = this;
    const LOADER_KEY = 'cancel-order';

    return $q((resolve, reject) => {
      const order = new Preoday.Order.constructor(this.order);
      order.statusReason = gettextCatalog.getString('Cancelled by user');
      delete order.venue;

      Spinner.show(LOADER_KEY);
      Preoday.Operate.cancelOrder(order)
        .then(cancelledOrder => {
          $scope.$applyAsync(() => {
            Object.keys(cancelledOrder).forEach((key) => (cancelledOrder[key] == null) && delete cancelledOrder[key]);
            Object.assign(this.order, cancelledOrder);
            Spinner.hide(LOADER_KEY);
            resolve(cancelledOrder);
          });
        }, (error) => {
          console.log('OrderDetail Drawer [cancelOrder] - error', error);
          $scope.$applyAsync(() => {
            Spinner.hide(LOADER_KEY);
            this.showError(error);
            reject(error);
          });
        });
    });
  }

  showError(error) {
    const {APIErrorCode, DialogService, LabelService, ErrorService} = this;

    if (error && error.errorCode === APIErrorCode.ORDER_STATUS_NOT_CANCELLABLE) {
      return DialogService.show(ErrorService.ORDER_STATUS_NOT_CANCELLABLE.title, ErrorService.ORDER_STATUS_NOT_CANCELLABLE.message, [{
        name: LabelService.CONFIRMATION
      }]);
    } else {
      return DialogService.show(ErrorService.FAILED_LOADING_ORDER.title, ErrorService.FAILED_LOADING_ORDER.message, [{
        name: LabelService.CONFIRMATION
      }]).then(() => {
        this.close();
      });
    }
  }

  isAmendOrCancelAvailable() {
    return this.PermissionService.hasPermission(this.Permissions.ORDER_DELETE) &&
           this.order && ['PENDING', 'ACCEPTED'].indexOf(this.order.status) > -1;
  }

  isRefundAvailable() {
    return this.PermissionService.hasPermission(this.Permissions.VENUE_CREATE) &&
     !this.isCustomersScreen()
      && this.order && this.order.status !== 'PENDING'
      && this.order.isRefundable && this.order.getAvailableAmountToRefund();
  }

  reorder() {
    const {StateService, OperateService, ErrorService, Snack} = this;

    if (!StateService.getOperateUrl()) {
      return Snack.showError(ErrorService.REQUIRED_CHANNEL_OPERATOR_URL.message);
    }

    OperateService.openNewTab();
    this.generateTokenAndGoToWeborders();
  }

  generateTokenAndGoToWeborders() {
    const {OperateService, Spinner, Snack, gettextCatalog} = this;
    const LOADER_KEY = 'generate-token';

    function _error(err) {
      console.log('Customer Order Detail [generateTokenAndGoToWeborders] - error', err);
      this.hideSpinner(LOADER_KEY);
      Snack.showError(gettextCatalog.getString('An error occurred to open the weborders, try again later please'));
    }

    Spinner.show(LOADER_KEY);

    OperateService.generateTokenAndGoToWeborders(this.order.userId, OperateService.getWebordersLinkByOrder(this.order))
      .then(() => {

        console.log('Customer Order Detail [generateTokenAndGoToWeborders] - weborders opened');
        this.hideSpinner(LOADER_KEY);
      }, _error.bind(this))
      .catch(_error.bind(this));
  }

  hideSpinner(loaderKey) {
    this.$rootScope.$applyAsync(() => {
      this.Spinner.hide(loaderKey);
    });
  }

  constructor($rootScope, $scope, $timeout, $window, $state, $stateParams, $q, StateService, DialogService, LabelService, ErrorService, OperateService, APIErrorCode, Spinner, Snack, gettextCatalog, PermissionService, Permissions) {
    'ngInject';
    // DEPENDENCIES
    this.$rootScope = $rootScope;
    this.$scope = $scope;
    this.$timeout = $timeout;
    this.$window = $window;
    this.$state = $state;
    this.$stateParams = $stateParams;
    this.$q = $q;
    this.StateService = StateService;
    this.DialogService = DialogService;
    this.LabelService = LabelService;
    this.ErrorService = ErrorService;
    this.OperateService = OperateService;
    this.APIErrorCode = APIErrorCode;
    this.Spinner = Spinner;
    this.Snack = Snack;
    this.gettextCatalog = gettextCatalog;
    this.PermissionService = PermissionService;
    this.Permissions = Permissions;
  }
}
