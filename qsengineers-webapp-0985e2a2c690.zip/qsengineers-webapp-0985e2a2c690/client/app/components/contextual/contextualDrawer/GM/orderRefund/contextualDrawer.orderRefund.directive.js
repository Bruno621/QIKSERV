import controller from './contextualDrawer.orderRefund.controller';

export default function contextualMenu() {
  'ngInject';

  return {
    restrict: 'E',
    scope: {
      order: '=',
      payments: '=',
      orderRefund: '='
    },
    bindToController: true,
    controller: controller.UID,
    controllerAs: 'drawerOrderRefundCtrl',
    template: require('./contextualDrawer.orderRefund.tpl.html'),
  };
}
