export default class ContextualDrawerOrderRefundController {
  static get UID() {
    return 'ContextualDrawerOrderRefund';
  }

  onToggleType() {
    if (this.orderRefund.type === this.RefundType.FULL) {
      this.maxValue = this.original.amount;
      this.orderRefund.amount = this.original.amount;
      this.orderRefund.paymentId = null;
    } else {
      // SET first payment option whether is not defined
      this.orderRefund.paymentId = this.orderRefund.paymentId || this.payments[0].id;

      this.updateInputAmountValue();
    }
  }

  onSelectType() {
    this.updateInputAmountValue();
  }

  updateInputAmountValue() {
    var paymentToRefund = this.payments.filter( p => p.id === this.orderRefund.paymentId)[0];

    // SET max value refund from chosen payment
    this.maxValue = paymentToRefund.total;
    if(paymentToRefund.refundTotal) {
      this.maxValue = this.maxValue - paymentToRefund.refundTotal;
    }
    this.orderRefund.amount = this.maxValue;
  }

  done() {
    const {ErrorService, Spinner, Snack, gettextCatalog, order, orderRefund} = this;
    const LOADER_KEY = 'order-refund';

    if (this.refundForm.$invalid) {
      return;
    }

    Spinner.show(LOADER_KEY);

    order.doRefund(orderRefund)
      .then(data => {
        // UPDATE order data
        angular.extend(this.order, data);
        // SHOW the success message
        Snack.show(gettextCatalog.getString('The order was refunded successfully.'));
        // REDIRECT to order details
        this.close();
      }).catch(err => {
        // SET a default error
        let error = err && err.message ? err : ErrorService.DEFAULT_RETRY;

        if (err && err.errorCode) {
          error = ErrorService[err.errorCode] || error;
        }
        // SHOW the error message
        Snack.showError(error.message);
      }).finally(() => {
        Spinner.hide(LOADER_KEY);
      });
  }

  close() {
    const {$state, $stateParams, order} = this;

    $state.go('main.dashboard.orders.detail', {
      orderId: $stateParams.orderId,
      order: order
    });
  }

  getMinRefundErrorMessage() {
    const {$filter, gettextCatalog, minValue} = this;

    return gettextCatalog.getString('Minimum value of {{amount}}.', {
      amount: $filter('currency')(minValue)
    });
  }

  getMaxRefundErrorMessage() {
    const {$filter, gettextCatalog, maxValue} = this;

    return [
      gettextCatalog.getString('Sorry, the amount you entered is greater than the remaining balance on this order.'),
      gettextCatalog.getString('The maximum amount you can refund is {{amount}}.', {
        amount: $filter('currency')(maxValue)
      }),
    ].join(' ');
  }

  constructor($state, $stateParams, $filter, ErrorService, RefundType, Spinner, Snack, gettextCatalog) {
    'ngInject';
    // DEPENDENCIES
    this.$state = $state;
    this.$stateParams = $stateParams;
    this.$filter = $filter;
    this.ErrorService = ErrorService;
    this.RefundType = RefundType;
    this.Spinner = Spinner;
    this.Snack = Snack;
    this.gettextCatalog = gettextCatalog;

    // DEFAULTS
    this.reasons = [
      gettextCatalog.getString('Out of stock'),
      gettextCatalog.getString('Customer cancellation'),
      gettextCatalog.getString('Customer complaint'),
    ];

    // SET the min/max refund value
    this.minValue = 0.01;
    this.maxValue = angular.copy(this.orderRefund.amount);

    // SET first reason option whether is not defined
    this.orderRefund.reason = this.orderRefund.reason || this.reasons[0];
    this.original = angular.copy(this.orderRefund);
  }
}
