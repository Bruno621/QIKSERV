export default class contextualDrawerOutletsController {
  static get UID() {
    return 'ContextualDrawerVenueDetails';
  }

  onInit() {
    const {StateService, Spinner, VenueImageType, $timeout} = this;
    const LOADER_KEY = 'venue-details';

    Spinner.show(LOADER_KEY);

    this.venue = angular.copy(StateService.venue);
    this.venue.cuisines = this.venue.cuisines || [];
    this.venueMapImages = [];

    if (this.venue && this.venue.images) {
      this.venueMapImages = this.venue.images.filter(image => {
        return image.type === VenueImageType.VENUE_MAP;
      });
    }

    $timeout(() => {
      Spinner.hide(LOADER_KEY);
    });
  }

  debounceUpdate(isAddress) {
    this.venueDetailsForm.$setSubmitted();
    this.isSaving = true;

    if (this.venueDetailsForm.$valid) {
      if (!this.isDebouncing) {
        this.isDebouncing = true;
        ++this.pendingRequests;
      }

      this.doUpdate();
    } else {
      this.$timeout(() => { // prevent super fast results
        this.isSaving = false;
        this.isError = true;
      }, 500);
    }
  }

  updateVenue() {
    const {StateService, LabelService, Snack, $q, $timeout, venue} = this;

    const promises = [
      StateService.updateVenue(venue), // venue update
      venue.settings.update() // venue settings update
    ];

    this.isDebouncing = false;

    $q.all(promises)
      .then(results => {
        this.onRequestResolved(results);
        this.isError = false;
      })
      .catch(err => {
        --this.pendingRequests;
        $timeout(() => {
          this.isError = true;
          // SHOW error message
          Snack.showError(LabelService.SNACK_VENUE_DETAILS_ERROR);
        });
      })
      .finally(() => {
        this.venue.cuisines = this.venue.cuisines || [];
        this.isSaving = false;
      });
  }

  onRequestResolved(results) {
    const {StateService, LabelService, Snack, venue} = this;

    --this.pendingRequests;

    console.log('ContextualDrawer VenueDetails [onRequestResolved] - ', this.pendingRequests);

    if (this.pendingRequests === 0) {
      angular.extend(venue, results[0]);
      angular.extend(StateService.venue, results[0]);
      angular.extend(StateService.venue.settings, results[1]);
      // SHOW success message
      Snack.show(LabelService.SNACK_VENUE_DETAILS_SUCCESS);
    }
  }

  setOnSaveImageState() {
    this.isSavingImage = true;
  }

  setOnImageSavedState() {
    this.isSavingImage = false;
    this.isErrorImage = false;
  }

  setOnImageErrorState() {
    this.isSavingImage = false;
    this.isErrorImage = true;
  }

  onVenueMapImageChange(image) {
    if (!angular.isObject(image)) {
      return;
    }

    const {StateService, VenueService, VenueImageType, venueMapImages} = this;

    // SET status to save/update image
    this.setOnSaveImageState();

    // SET image type
    image.type = VenueImageType.VENUE_MAP;

    VenueService.saveImage(StateService.venue, image)
      .then(updatedImage => {
        console.log('ContextualDrawer VenueDetails - image saved');

        angular.extend(updatedImage, image);
        updatedImage.$save = false;

        // RESET statuses to save/update image
        this.setOnImageSavedState();

        venueMapImages.splice(venueMapImages.indexOf(image), 1, updatedImage);
      }, err => {
        console.log('ContextualDrawer VenueDetails - error saving image', err);
        // SET `error` status to save/update image
        this.setOnImageErrorState();
      });
  }

  onVenueMapImageDeleted(image) {
    if (!angular.isObject(image)) {
      return;
    }

    const {$timeout, venueMapImages} = this;

    // SET status to remove image
    this.setOnSaveImageState();

    image.delete()
      .then(() => {
        $timeout(() => {
          console.log('ContextualDrawer VenueDetails - image deleted');

          venueMapImages.splice(venueMapImages.indexOf(image), 1);
          this.setOnImageSavedState();
        });
      }, err => {
        console.log('ContextualDrawer VenueDetails - error deleting image', err);
        // SET `error` status to remove image
        this.setOnImageErrorState();
      });
  }

  onTransformCuisineChip(item) {
    if (this.venueDetailsForm.cuisine.$invalid) {
      this.venueDetailsForm.$setSubmitted();
      this.cuisineSearchText = item;
      return null;
    }

    this.venueDetailsForm.cuisine.$setPristine();
    this.cuisineSearchText = '';
    return item;
  }

  constructor($scope, $q, $timeout, $mdConstant, StateService, VenueService, LabelService, UtilsService, Spinner, Snack, BroadcastEvents, VenueImageType) {
    'ngInject';
    // NG dependencies
    this.$q = $q;
    this.$timeout = $timeout;

    // Servicess
    this.StateService = StateService;
    this.VenueService = VenueService;
    this.LabelService = LabelService;
    this.Spinner = Spinner;
    this.Snack = Snack;

    // Constants
    this.VenueImageType = VenueImageType;

    // Defaults
    this.cuisineSearchText = '';
    this.isError = false;
    this.isSaving = false;
    this.isDebouncing = false;
    this.pendingRequests = 0;

    // SET a debounce time to update venue
    this.doUpdate = UtilsService.debounce(this.updateVenue, 1000);

    // Separator keys to use in mdChip component
    this.separatorKeys = [
      $mdConstant.KEY_CODE.ENTER,
      $mdConstant.KEY_CODE.COMMA,
      186 // semicolon
    ];

    // Listen event to update venue location
    $scope.$on(BroadcastEvents.ON_VENUE_LOCATION_UPDATED, () => {
      angular.extend(this.venue, StateService.venue);
    });

    this.onInit();
  }
}
