import './venueDetailsForm.scss';

export default function venueDetailsForm() {
  'ngInject';

  return {
    restrict: 'E',
    replace: true,
    template: require('./venueDetailsForm.tpl.html')
  };
}
