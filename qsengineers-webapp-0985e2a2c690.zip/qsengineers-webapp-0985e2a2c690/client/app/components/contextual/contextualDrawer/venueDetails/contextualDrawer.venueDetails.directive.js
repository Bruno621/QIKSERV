import controller from './contextualDrawer.venueDetails.controller'

export default function contextualVenueDetails() {
  'ngInject';
  return {
    restrict: 'E',
    replace: true,
    transclude: true,
    controller: controller.UID,
    controllerAs: 'drawerVenueDetailsCtrl',
    bindToController: true,
    template: require('./contextualDrawer.venueDetails.tpl.html')
  };
}
