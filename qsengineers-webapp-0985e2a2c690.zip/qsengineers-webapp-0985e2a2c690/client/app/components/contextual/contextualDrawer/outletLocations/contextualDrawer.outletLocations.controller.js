export default class contextualDrawerOutletLocationsController {
  static get UID(){
    return 'ContextualDrawerOutletLocations';
  }

  fetchOutletLocations() {
    const {StateService, OutletLocationService} = this;

    OutletLocationService.getOutletLocations({
      venueId: StateService.venue.id
    }).then(data => {
      this.data = data;
    }, err => {
      console.log('ContextualDrawerOutletLocations - error fetching outlet locations', err);
      this.data = {};
    });
  }

  onSelectOutletLocation(outletLocation) {
    const {OutletLocationService, Snack, gettextCatalog} = this;
    const outletLocationToMove = OutletLocationService.getOutletLocationToMove();

    if (outletLocationToMove.id === outletLocation.id) {
      Snack.showError(gettextCatalog.getString('You need select a different outlet location destination'));
      return;
    }

    if (outletLocation.path && outletLocation.path.indexOf('/' + outletLocationToMove.id + '/') !== -1) {
      Snack.showError(gettextCatalog.getString('You need select a different outlet location destination'));
      return;
    }

    if (!outletLocation.isGroup && outletLocation.hasAvailableService()) {
      Snack.showError(gettextCatalog.getString('You can not add children for outlet location with service set up'));
      return;
    }

    if (outletLocation.outletId) {
      Snack.showError(gettextCatalog.getString('You can not add children for an outlet location with an outlet'));
      return;
    }

    this.selectedOutletLocation = outletLocation;
  }

  onMove() {
    let groupToMove = null;

    if (this.selectedOutletLocation.isGroup) {
      groupToMove = Preoday.OutletLocationGroup.getGroupById(null);
    } else {
      groupToMove = this.selectedOutletLocation.createGroup();
    }

    this.selectedOutletLocation = null;
    this.contextualDrawer.success(groupToMove);
  }

  onClose() {
    this.selectedOutletLocation = null;
    this.contextualDrawer.cancel();
  }

  constructor(StateService, OutletLocationService, Snack, gettextCatalog, contextualDrawer) {
    'ngInject';

    // Services
    this.StateService = StateService;
    this.OutletLocationService = OutletLocationService;
    this.Snack = Snack;
    this.gettextCatalog = gettextCatalog;
    this.contextualDrawer = contextualDrawer;

    // Defaults
    this.selectedOutletLocation = null;

    this.fetchOutletLocations();
  }
}
