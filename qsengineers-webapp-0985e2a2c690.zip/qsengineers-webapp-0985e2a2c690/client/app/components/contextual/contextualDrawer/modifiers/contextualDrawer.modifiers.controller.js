export default class contextualDrawerItemController {
  static get UID(){
    return "ContextualDrawerModifier";
  }

  onNewModifierMoved($items, $partFrom, $partTo, $indexFrom, $indexTo){
    console.log("on cancel move"); //dont need to do anything here, just want to cancel the move
  }

  navigateToPage(){
    this.$state.go("main.dashboard.menus.modifiers")
  }

  close(){
    this.contextualDrawer.close();
  }

  makeSearch() {

    console.log('contextualDrawer.modifiers [makeSearch] - ', this.searchText);

    const _searchText = this.searchText && this.searchText.toLowerCase();
    this.modifiers = this.allModifiers.filter((modifier) => {
      return !_searchText || modifier.internalName.toLowerCase().indexOf(_searchText) !== -1
    });

    ++this.lastListUpdate;
    this.modifiersLimit = this.modifiersQuantityRenderer;
  }

  onInfiniteScroll() {

    console.log('ContextualDrawerModifier [onInfiniteScroll]', this.modifiersLimit);

    if (this.modifiersLimit + this.modifiersQuantityRenderer > this.modifiers.length) {
      this.modifiersLimit = this.modifiers.length;
    } else {
      this.modifiersLimit += this.modifiersQuantityRenderer;
    }
  }

  constructor($scope, ModifierService, $stateParams, $state, contextualDrawer, BroadcastEvents) {
    "ngInject";

    this.$state = $state;
    this.contextualDrawer = contextualDrawer;

    this.cancelledModifiers = [];

    console.log('ContextualDrawerModifier [constructor]');

    this.modifiersQuantityRenderer = 10;
    this.modifiersLimit = this.modifiersQuantityRenderer;
    this.allModifiers = ModifierService.data.modifiers;
    this.modifiers = this.allModifiers;
    this.drawerOpened = false;

    const unRegisterDrawerOpenedListener = $scope.$on(BroadcastEvents.ON_CONTEXTUAL_DRAWER_OPENED, () => {
      console.log('contextualDrawer.items [ON_CONTEXTUAL_DRAWER_OPENED]');
      if (typeof this.lastUpdate === 'undefined') {
        this.lastUpdate = 0;
        this.lastListUpdate = 0;
        this.drawerOpened = true;
      }
    });

    $scope.$on('$destroy', () => {
      unRegisterDrawerOpenedListener && unRegisterDrawerOpenedListener();
    });
  }
}
