export default class contextualDrawerUserSearchController {
  static get UID(){
    return "ContextualDrawerUserSearch";
  }

  toogle(user) {
    
    const index = this.selectedList.map((item) => {return item.id}).indexOf(user.id);
    if (index === -1) {
      this.selectedList.push(user);
    } else {
      this.selectedList.splice(index, 1);
    }
  }

  onCancel(){

    this.contextualDrawer.cancel();
  }

  apply() {

    if(!this.selectedList) {
      this.selectedList = [];
    }

    this.contextualDrawer.successWithoutClose({"users": this.selectedList});
  }

  getUsersFromOffer(offerId) {

    if(!offerId) {
      return;
    }

    this.Spinner.show('user-get-offer');
    this.OfferService.getAvailableUsersForOffer(offerId)
    .then((users) => {
      this.selectedList = users;
      this.Spinner.hide('user-get-offer');
    }, (err) => {
      this.Spinner.hide('user-get-offer');
      this.Snack.showError(this.ErrorService.DEFAULT.message);
    });
  }

  constructor($scope, $stateParams, $mdSidenav, Spinner, BroadcastEvents, Snack, contextualDrawer, ErrorService, OfferService) {
    "ngInject";
    this.$mdSidenav = $mdSidenav;
    this.cancelledOutlets = [];
    this.Spinner = Spinner;
    this.contextualDrawer = contextualDrawer;
    this.OfferService = OfferService;
    this.ErrorService = ErrorService;
    this.Snack = Snack;

    this.selectedList = [];

    $scope.$on(BroadcastEvents.ON_CONTEXTUAL_DRAWER_OPENED, () => {
      this.getUsersFromOffer($stateParams.promotionId);
    });

    $scope.$on('$onSideNavClose', () =>{

      this.selectedList = [];
    });
  
  }
}
