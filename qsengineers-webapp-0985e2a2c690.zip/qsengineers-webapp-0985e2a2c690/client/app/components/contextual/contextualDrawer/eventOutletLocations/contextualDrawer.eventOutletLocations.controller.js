export default class ContextualDrawerEventOutletLocationsController {
  static get UID() {
    return 'ContextualDrawerEventOutletLocations';
  }

  close() {
    this.selectedOutletLocation = null;
    this.contextualDrawer.cancel();
  }

  fetchOutletLocations() {
    this.OutletLocationService.getOutletLocations({
      venueId: this.StateService.venue.id
    }).then((data) => {

      this.data = data;
    }, (err) => {

      this.data = {};
    });
  }

  selectOutletLocation(outletLocation) {
    this.selectedOutletLocation = outletLocation;
  }

  done() {
    const outletLocation = this.selectedOutletLocation;
    this.selectedOutletLocation = null;

    this.contextualDrawer.success(outletLocation);
  }

  constructor(StateService, OutletLocationService, contextualDrawer) {
    'ngInject';

    // Services
    this.StateService = StateService;
    this.OutletLocationService = OutletLocationService;
    this.contextualDrawer = contextualDrawer;

    // Defaults
    this.selectedOutletLocation = null;

    this.fetchOutletLocations();
  }
}
