export default class contextualDrawerItemController {
  static get UID(){
    return "ContextualDrawerItem";
  }

  close(){
    return this.$mdSidenav('items').close()
  }

  navigateToPage(){
    this.$state.go("main.dashboard.menus.itemList")
  }

  checkTypes () {

    let currentMenu = this.MenuService.getCurrentMenu();
    if (currentMenu) {
      if (currentMenu.isVoucher()) {
        this.types = ['ALL', 'EMAIL', 'POST'];
      } else {
        this.types = ['NONE'];
      }
    } else {
      this.types = ['NONE'];
    }
  }

  search() {
    const _searchText = this.searchText && this.searchText.toLowerCase();
    this.items = this.allItems.filter((item) => {
      return !_searchText || (item.internalName && item.internalName.toLowerCase().indexOf(_searchText) !== -1)
    });
  }

  makeSearch() {

    console.log('contextualDrawer.items [makeSearch] - ', this.searchText);

    this.search();

    ++this.lastListUpdate;
    this.itemsLimit = this.itemsQuantityRenderer;
  }

  onInfiniteScroll() {

    console.log('ContextualDrawerItems [onInfiniteScroll]', this.itemsLimit);

    if (this.itemsLimit + this.itemsQuantityRenderer > this.items.length) {
      this.itemsLimit = this.items.length;
    } else {
      this.itemsLimit += this.itemsQuantityRenderer;
    }
  }

  buildItems() {
    this.allItems = this.ItemService.getItems().filter((item) => {
      return this.types.indexOf(item.voucherType) !== -1;
    });
  }

  constructor($scope, ItemService, $stateParams, $mdSidenav, $state, MenuService, BroadcastEvents) {
    "ngInject";
    this.$mdSidenav = $mdSidenav;
    this.$scope = $scope;
    this.$state = $state;
    this.MenuService = MenuService;
    this.ItemService = ItemService;

    this.cancelledItems = [];
    this.types = ['NONE'];
    this.drawerOpened = false;

    this.itemsQuantityRenderer = 10;
    this.itemsLimit = this.itemsQuantityRenderer;
    this.checkTypes();
    this.buildItems();

    this.items = this.allItems;

    console.log('contextualDrawer.items [constructor]');

    const unRegisterListener = $scope.$on(BroadcastEvents.ON_ITEM_CREATED, () => {
      console.log('contextualDrawer.items [ON_ITEM_CREATED]');
      // build / rebuild items
      this.buildItems();
      this.search();

      if (angular.isDefined(this.lastUpdate)) {
        ++this.lastUpdate;
      }
    });

    const unRegisterDrawerOpenedListener = $scope.$on(BroadcastEvents.ON_CONTEXTUAL_DRAWER_OPENED, () => {
      console.log('contextualDrawer.items [ON_CONTEXTUAL_DRAWER_OPENED]');
      if (angular.isUndefined(this.lastUpdate)) {
        this.lastUpdate = 0;
        this.lastListUpdate = 0;
        this.drawerOpened = true;
      }
    });

    $scope.$on('$destroy', () => {
      unRegisterListener && unRegisterListener();
      unRegisterDrawerOpenedListener && unRegisterDrawerOpenedListener();
    });
  }
}
