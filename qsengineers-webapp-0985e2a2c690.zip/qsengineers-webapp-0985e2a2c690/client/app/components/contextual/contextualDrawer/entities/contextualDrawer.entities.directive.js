
import controller from './contextualDrawer.entities.controller';

import './contextualDrawer.scss';

export default function contextualMenu() {
  'ngInject';

  return {
    restrict: 'E',
    controller: controller.UID,
    controllerAs: 'drawerEntitiesCtrl',
    scope: {},
    bindToController: {
      entities: '=?',
      callback: '&?'
    },
    template: require('./contextualDrawer.entities.tpl.html')
  };
}
