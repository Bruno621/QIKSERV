export default class ContextualDrawerEventsImportController {
  static get UID() {
    return 'ContextualDrawerEventsImport';
  }

  onInit() {
    if (!this.hasChanges) {
      this.entity = this.ExternalService.getEntityEvent();
    }

    if (!this.entity || this.isLinkingToEvent) {
      this.isImportMode = true;

      if (!this.events.length || this.ExternalService.getHasChanges()) {
        return this.fetchExternalEvents();
      }
      return this.setContextualProperties();
    }

    this.isEditMode = true;

    this.entity.externalEvents.forEach((externalEvent, index) => {
      externalEvent.id = index;
      externalEvent.eventDateFormated = moment(externalEvent.eventDate).format('llll');
      externalEvent.name = this.entity.name;
      externalEvent.$deleted = false;
      externalEvent.$selected = false;
    });

    this.setContextualProperties();
  }

  onReset(shouldResetEvents) {
    this.selectedEvents = [];
    this.slots.pickupSlots = [];

    this.isEditMode = false;
    this.isImportMode = false;
    this.shouldShowDoneButton = false;
    this.isLinkingToEvent = false;

    if (shouldResetEvents) {
      this.events = [];
    }
  }

  onAddToEvent() {
    this.isEditMode = false;
    this.isLinkingToEvent = true;
    this.onInit();
  }

  close() {
    if (this.isLinkingToEvent) {
      this.isImportMode = false;
      this.isLinkingToEvent = false;
      return this.onInit();
    }

    this.onReset();
    this.contextualDrawer.cancel();
  }

  done(shouldResetEvents) {
    const {contextualDrawer, hasChanges, entity} = this;

    this.onReset(shouldResetEvents);
    contextualDrawer.success({hasChanges: hasChanges, event: entity});
  }

  onItemClicked(event) {
    if (!event.$selected) {
      const index = this.selectedEvents.indexOf(event);
      this.selectedEvents.splice(index, 1);
    } else {
      this.selectedEvents.push(event);
    }
  }

  onItemDelete() {
    this.events = [];
  }

  import() {
    const {ExternalService, Spinner, Snack, contextualDrawer, gettextCatalog} = this;

    if (!this.entity && !this.slots.pickupSlots.length) {
      if (this.selectedTab !== 1) {
        this.selectedTab = 1;
      }
      return;
    }

    // After inserting, the GET method must return only occurrences after >= last week
    const params = {after: moment().subtract(7, 'days').format('YYYY-MM-DD')};
    const LOADER_KEY = 'drawer-events-import';

    Spinner.show(LOADER_KEY);

    if (this.entity) {
      return ExternalService.addTMEventToExistentEvent(this.entity.id, this.venueId, this.selectedEvents, params)
        .then(data => {
          Snack.show(gettextCatalog.getString('Events imported successfully.'));
          this.hasChanges = true;
          this.entity = data;
          this.done(true);
        }, (err) => {
          this.onReset();
          contextualDrawer.cancel(err);
        }).finally(() => {
          Spinner.hide(LOADER_KEY);
        });
    }

    ExternalService.importTicketMasterEventToPreoday(this.venueId, this.selectedEvents, this.slots.pickupSlots, params)
      .then(data => {
        this.onReset(true);
        contextualDrawer.success(data);
      }, err => {
        this.onReset();
        contextualDrawer.cancel(err);
      }).finally(() => {
        Spinner.hide(LOADER_KEY);
      });
  }

  fetchExternalEvents() {
    const {ExternalService, Snack, gettextCatalog} = this;

    this.loading = true;
    this.setContextualProperties();

    ExternalService.getTicketMasterEvents([this.venueId])
      .then(data => {
        this.events = data;
        this.setContextualProperties();
        ExternalService.setHasChanges(false);
      }, err => {
        console.log('[ContextualDrawerEventsImport] error fetching TM events', err);
        Snack.showError(gettextCatalog.getString('An error occurred while trying to fetch Ticket Master events. Please try again.'));
      }).finally(() => {
        this.loading = false;
      });
  }

  setContextualProperties() {
    if (this.isEditMode) {
      this.shouldShowDoneButton = true;
      return;
    }
    // Import mode
    this.shouldShowDoneButton = false;

    if (this.isLinkingToEvent) {
      this.cancelButtonLabel = this.gettextCatalog.getString('Back');
      this.importButtonLabel = this.gettextCatalog.getString('Add to event');
      return;
    }

    this.cancelButtonLabel = this.gettextCatalog.getString('Cancel');
    this.importButtonLabel = this.gettextCatalog.getString('Import');
  }

  constructor($scope, StateService, ExternalService, BroadcastEvents, Spinner, Snack, contextualDrawer, gettextCatalog) {
    'ngInject';
    // DEPENDENCIES
    this.ExternalService = ExternalService;
    this.Spinner = Spinner;
    this.Snack = Snack;
    this.contextualDrawer = contextualDrawer;
    this.gettextCatalog = gettextCatalog;

    // DEFAULTS
    this.venueId = StateService.venue.id;
    this.slots = {pickupSlots: []};
    this.selectedEvents = [];
    this.events = [];

    $scope.$on(BroadcastEvents.ON_CONTEXTUAL_DRAWER_OPEN, (ev, drawer) => {
      if (drawer && drawer.id !== 'eventsImport') {
        // AVOID request when opening other drawers (i.e eventOutletLocations)
        return;
      }

      this.hasChanges = false;
      this.isImportMode = false;
      this.isEditMode = false;
      this.isLinkingToEvent = false;
      this.onInit();
    });
  }
}
