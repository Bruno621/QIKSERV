export default class contextualDrawerStylePayAtTableController {
  static get UID() {
    return 'contextualDrawerStylePayAtTableController';
  }

  initListeners() {
    const { $rootScope, $scope, StyleService, model } = this;

    const unRegisterLocationChangeListener = $rootScope.$on('$locationChangeSuccess', () => {
      this.restoreSearch();
    });

    const unRegisterWebSettingsListener = $scope.$watch(() => {
      return model.webSettings;
    }, () => {
      StyleService.updateWebSettingsInReducer(model.webSettings);
      this.updateSaveButtonState();
    }, true);

    const unRegisterImagesListener = $scope.$watch('$drawer.StyleService.imagesModel', newValue => {
      model.images = newValue;
    });

    $scope.$on('$destroy', () => {
      // TODO: What is the best way of handling it?
      // 1 - Restoring the data in the `$destroy` event
      // 2 - Using a separaed reducer prop to handle the editing values
      // Restore the Reducer to the original values
      StyleService.updateWebSettingsInReducer();
      StyleService.updateImagesInReducer();

      unRegisterLocationChangeListener && unRegisterLocationChangeListener();
      unRegisterWebSettingsListener && unRegisterWebSettingsListener();
      unRegisterImagesListener && unRegisterImagesListener();
    });
  }

  getWebSettings() {
    const { StyleService, Spinner, LOADER_KEY } = this;

    Spinner.show(LOADER_KEY);

    StyleService.getWebSettings()
      .then(webSettings => {
        // SET web settings
        this.model.webSettings = webSettings || new Preoday.WebSettings();
        this.model.images = StyleService.imagesModel;

        // CREATE a copy of the original model
        this.originalModel = angular.copy(this.model);
        this.restoreImages();
      })
      .catch(err => {
        console.error(err);
      })
      .finally(() => {
        Spinner.hide(LOADER_KEY);
      });
  }

  updateSaveButtonState() {
    this.isSaveButtonEnabled = this.shouldEnableSaveButton();
  }

  save() {
    const { LabelService, Spinner, Snack, model, payAtTableForm, LOADER_SAVE_KEY } = this;

    if (payAtTableForm.$invalid) {
      return;
    }

    Spinner.show(LOADER_SAVE_KEY);

    return this.saveImage()
      .then(this.saveWebSettings.bind(this))
      .then(data => {
        Snack.show(LabelService.SNACK_PAY_AT_TABLE_STYLING_SUCCESS);

        // UPDATE original model
        this.originalModel = angular.copy(model);
        this.restoreImages();
        this.updateSaveButtonState();
      })
      .catch(() => {
        Snack.showError(LabelService.SNACK_PAY_AT_TABLE_STYLING_ERROR);
      })
      .finally(() => {
        Spinner.hide(LOADER_SAVE_KEY);
      });
  }

  saveImage() {
    const { $q, StyleService, venueId } = this;

    // GET logo image
    let payTableLogoImage = null;

    if (StyleService.imagesModel.$images.payTableLogoImage) {
      payTableLogoImage = StyleService.imagesModel.$images.payTableLogoImage[0];
    }

    if (!payTableLogoImage || !payTableLogoImage.$save) {
      return $q.resolve();
    }

    // SAVE image to CDN
    return Preoday.VenueImage.saveToCdn(payTableLogoImage.$image, venueId, null);
  }

  saveWebSettings(data) {
    const { $q, model, venueId } = this;

    // SET logo image path
    if (data && data.image) {
      model.webSettings.payTableLogoImage = data.image || null;
    }

    return $q((resolve, reject) => {
      if (model.webSettings.id) {
        return model.webSettings.update()
          .then(resolve, reject)
          .catch(error => {
            console.error('Error updating Venue Web Settings - ', error);
            reject(error);
          });
      }

      model.webSettings.venueId = venueId;

      Preoday.WebSettings.save(model.webSettings)
        .then(data => {
          angular.extend(model.webSettings, data);
          resolve(data);
        })
        .catch(error => {
          console.error('Error saving Venue Web Settings - ', error);
          reject(error);
        });
    });
  }

  shouldEnableSaveButton() {
    const { StyleService, model, originalModel } = this;
    const { webSettings } = model;

    if (!originalModel || !webSettings) {
      return false;
    }

    const logoImage = webSettings.payTableLogoImage;
    const backgroundColour = webSettings.payTableLoadingBackgroundColour
    const textContent = webSettings.payTableLoadingText;
    const textColour = webSettings.payTableLoadingTextColour;

    if ((!logoImage && originalModel.webSettings.payTableLogoImage)
      || (logoImage && !originalModel.webSettings.payTableLogoImage)
      || (logoImage != originalModel.webSettings.payTableLogoImage)) {
      return true;
    }

    if ((!backgroundColour && originalModel.webSettings.payTableLoadingBackgroundColour)
      || (backgroundColour && !originalModel.webSettings.payTableLoadingBackgroundColour)
      || (backgroundColour != originalModel.webSettings.payTableLoadingBackgroundColour)) {
      return true;
    }

    if ((!textContent && originalModel.webSettings.payTableLoadingText)
      || (textContent && !originalModel.webSettings.payTableLoadingText)
      || (textContent != originalModel.webSettings.payTableLoadingText)) {
      return true;
    }

    if ((!textColour && originalModel.webSettings.payTableLoadingTextColour)
      || (textColour && !originalModel.webSettings.payTableLoadingTextColour)
      || (textColour != originalModel.webSettings.payTableLoadingTextColour)) {
      return true;
    }

    const { imagesModel } = StyleService;

    if (imagesModel.$images && imagesModel.$images.payTableLogoImage) {
      const payTableLogoImage = imagesModel.$images.payTableLogoImage[0];

      if (payTableLogoImage && payTableLogoImage.$save) {
        return true;
      }
    }

    return false;
  }

  restoreSearch() {
    const { UtilsService, DRAWER_KEY } = this;
    const drawerStyleParam = UtilsService.getQueryParam(DRAWER_KEY);

    if (drawerStyleParam) {
      this.toggleExpanded({ id: drawerStyleParam });
    } else {
      this.toggleExpanded({ id: 'payAtTableLogo' });
    }
  }

  restoreImages() {
    const { StyleService } = this;
    StyleService.updateImagesForEditingWebSettings();
  }

  toggleExpanded(style) {
    const { $location, styles, DRAWER_KEY } = this;

    if (!style) {
      styles.forEach(_style => { // collapse all
        _style.expanded = false;
      });
      return;
    }

    // GET current opened drawer's section
    const section = styles.find(_style => _style.id === style.id);

    if (section && !section.expanded) {
      styles.forEach(_style => { // collapse all
        _style.expanded = _style.id === style.id;
      });

      $location.search(DRAWER_KEY, section.id);
    }
  }

  onImageUpload(key, image) {
    const { StyleService, model } = this;

    if (image && image.$delete) {
      // RESET logo image in `web settings` data
      model.webSettings.payTableLogoImage = null;

      // RESET logo image in Style service
      StyleService.imagesModel.$images.payTableLogoImage = [];
    }

    StyleService.updateImagesInReducer(StyleService.imagesModel.$images);
    this.updateSaveButtonState();
  }

  constructor($rootScope, $scope, $q, $location, // NG dependencies
    StateService, StyleService, LabelService, UtilsService,
    Spinner, Snack, gettextCatalog) {
    'ngInject';

    // NG dependencies
    this.$rootScope = $rootScope;
    this.$scope = $scope;
    this.$q = $q;
    this.$location = $location;

    // Services
    this.StyleService = StyleService;
    this.LabelService = LabelService;
    this.UtilsService = UtilsService;
    this.Spinner = Spinner;
    this.Snack = Snack;

    // Constants
    this.DRAWER_KEY = 'drawer-paytable-style';
    this.LOADER_KEY = 'style-drawer-paytable';
    this.LOADER_SAVE_KEY = 'style-drawer-paytable-saving';

    // Defaults
    this.venueId = StateService.venue && StateService.venue.id;

    this.styles = [{
      id: 'payAtTableLogo',
      name: gettextCatalog.getString('Logo'),
      height: '165px',
    }, {
      id: 'payAtTableBackground',
      name: gettextCatalog.getString('Background colour'),
      height: '80px',
    }, {
      id: 'payAtTableText',
      name: gettextCatalog.getString('Loading text'),
      height: '160px',
    }];

    this.model = {
      images: [],
      webSettings: {}
    };

    this.initListeners();
    this.restoreSearch();

    // GET venue `web settings`
    this.getWebSettings();
  }
}
