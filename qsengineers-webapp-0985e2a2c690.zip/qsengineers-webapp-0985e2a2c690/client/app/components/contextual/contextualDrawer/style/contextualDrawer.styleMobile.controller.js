export default class contextualDrawerStyleMobileController {
  static get UID() {
    return 'ContextualDrawerStyleMobile';
  }

  _restoreImages() {
    const { StyleService } = this;

    StyleService.updateImagesForEditingAppSingleVenue();
  }

  _saveImagesToCdn() {
    var promises = []
    angular.forEach(this.StyleService.imagesModel.$images,(imageObject, key)=>{
      let img = imageObject[0];
      if (img){
        if (img.$save) {
          let p = Preoday.VenueImage.saveToCdn(img.$image, this.venueId, this.channelId)
          .then((itemImage) => {

            if (this.StyleService.imagesModel[key]) {
              angular.extend(this.StyleService.imagesModel[key], {src:itemImage.image});
            } else {
              this.StyleService.imagesModel[key] = {src:itemImage.image};
            }

            this.imageSaved = true;
          });
          promises.push(p);
        }
      }
    });

    if (promises.length === 0){
      console.log("Item does not have images")
    }

    return this.$q.all(promises);
  }

  onImageUpload() {
    const { StyleService } = this;

    StyleService.updateImagesInReducer(StyleService.imagesModel.$images);
    this.updateSaveButtonState();
  }

  onImageDelete(key, image){
    if (key && image){ //only one key here
      this.DialogService.delete(this.LabelService.TITLE_DELETE_ITEM_IMAGE, this.LabelService.CONTENT_DELETE_ITEM_IMAGE)
      .then(()=> {
        this.Spinner.show("venue-image-delete");
        let img = this.StyleService.imagesModel[key];

        this.model.mobileSettings.wallpaper = null;
        this.model.mobileSettings.update()
        .then(() => {
          img.delete()
          .finally(() => {
            this.StyleService.imagesModel[key] = new Preoday.VenueImage();
            this.StyleService.imagesModel.$images[key]= [];
            this.originalModel.images[key] = new Preoday.VenueImage();
            this.originalModel.images.$images[key]= [];
            this.StyleService.updateImagesInReducer(this.StyleService.imagesModel.$images);
            this.Snack.show(this.LabelService.IMAGE_DELETE_SUCCESS);
            this.Spinner.hide("venue-image-delete");
          });
        })
        .catch((err)=>{
          console.log("Failed deleting item image", err)
          this.Spinner.hide("venue-image-delete")
          this.Snack.showError(this.LabelService.IMAGE_DELETE_ERROR);
        });
      });
    }
  }

  saveVenueImages() {

    return this.$q((resolve,reject)=>{
      this._saveImagesToCdn()
      .then(()=>{
        var promises = [];
        angular.forEach(this.StyleService.imagesModel.$images,(img,key)=>{
          let image = img[0];
          if(image && image.$save){
              let venueImage = this.StyleService.imagesModel[key];

              if(venueImage.src){
                if(venueImage.id){
                  promises.push(venueImage.update());
                } else {
                  venueImage.venueId = this.venueId;
                  venueImage.channelId = this.channelId;
                  promises.push(
                    Preoday.VenueImage.create(venueImage)
                    .then((newImg)=>{
                      angular.extend(this.StyleService.imagesModel[key], newImg);
                    })
                  );
                }
              }
          }
        });

        this.$q.all(promises).then(resolve, reject);
      }).catch((err)=>{
        console.error('Error saving Venue IMages - ', err);
        reject(err);
      })
    });
  }

  saveSettings() {
    return this.$q((resolve, reject) => {
      let obj = {
        wallpaper: this.model.images[this.drawerKey] ? this.model.images[this.drawerKey].id : '',
        buttonColour: this.model.colors.buttonColour ? this.model.colors.buttonColour.substr(1) : '', // jump first # character
        buttonTextColour: this.model.colors.buttonTextColour ? this.model.colors.buttonTextColour.substr(1) : ''  // jump first # character
      };
      angular.merge(this.model.mobileSettings, obj);

      if (this.model.mobileSettings.id) {
        this.model.mobileSettings.update()
        .then(resolve, reject)
        .catch((err)=>{
          console.error('Error updating Venue Mobile Settings - ', err);
          reject(err);
        });
      } else {

        this.model.mobileSettings.venueId = this.venueId;
        this.model.mobileSettings.channelId = this.channelId;

        Preoday.MobileSettings.save(this.model.mobileSettings)
        .then((newSettings) => {
          angular.extend(this.model.mobileSettings, newSettings);
          angular.extend(this.StyleService.mobileSettings, newSettings);
          this.StyleService.mobileExtendModels(newSettings);
          resolve(newSettings);
        })
        .catch((err)=>{
          console.error('Error saving Venue Mobile Settings - ', err);
          reject(err);
        });
      }

    });
  }

  saveAll() {
    return this.saveVenueImages()
      .then(this.saveSettings.bind(this))
  }

  save() {
    if (this.styleMobileForm.$invalid) {
      return;
    }

    this.showSavingSpinner();
    return this.saveAll().then((data) => {
      this.hideSavingSpinner();

      if (!data.hideSave || this.imageSaved) {
        this.Snack.show(this.LabelService.SNACK_MOBILE_STYLING_SUCCESS)
      }

      this.imageSaved = false;
      this.originalModel = angular.copy(this.model);

      this._restoreImages();
      this.updateSaveButtonState();      
    }).catch(() => {
      this.hideSavingSpinner();
      this.Snack.showError(this.LabelService.SNACK_MOBILE_STYLING_ERROR)
    });
  }

  toggleExpanded(style) {
    const { $location, styles } = this;
    if (!style) {
      styles.forEach((s) => { // collapse all
        s.expanded = false;
      });
      return;
    }

    const found = styles.find(i => i.id === style.id);
    if (found && !found.expanded) {
      styles.forEach((i) => { // collapse all
        i.expanded = i.id === style.id;
      });

      $location.search('drawer-mobile-style', found.id);
    }
  }

  restoreSearch() {
    const { UtilsService } = this;
    const drawerStyleParam = UtilsService.getQueryParam('drawer-mobile-style');

    if (drawerStyleParam) {
      this.toggleExpanded({ id: drawerStyleParam });
    }
  }

  shouldEnableSaveButton() {
    const { StyleService, model } = this;
    let hasChanges = false;
    const { mobileSettings } = model;

    const buttonColour = mobileSettings && mobileSettings.buttonColour && `#${mobileSettings.buttonColour}`;
    const buttonTextColour = mobileSettings && mobileSettings.buttonTextColour && `#${mobileSettings.buttonTextColour}`;
    const wallpaper = mobileSettings && mobileSettings.wallpaper;

    if (!buttonColour && model.colors.buttonColour ||
      buttonColour && !model.colors.buttonColour ||
      buttonColour != model.colors.buttonColour ) {
      return true;
    }

    if (!buttonTextColour && model.colors.buttonTextColour ||
      buttonTextColour && !model.colors.buttonTextColour ||
      buttonTextColour != model.colors.buttonTextColour ) {
      return true;
    }

    if (model.images[this.drawerKey] &&
       (!wallpaper && model.images[this.drawerKey].id ||
        wallpaper && !model.images[this.drawerKey].id ||
        model.images[this.drawerKey].id != wallpaper)) {
      return true;
    }

    if (StyleService.imagesModel.$images) {
      angular.forEach(StyleService.imagesModel.$images, (value, key) => {
        const image = value[0];
        if (image && image.$save) {
          hasChanges = true;
        }
      });
    }

    return hasChanges;    
  }

  updateSaveButtonState() {
    this.saveButtonEnabled = this.shouldEnableSaveButton();
  }

  showSavingSpinner() {
    this.Spinner.show('style-mobile-saving');
  }

  hideSavingSpinner() {
    this.Spinner.hide('style-mobile-saving');
  }

  showSpinner() {
    this.Spinner.show('style-drawer-mobile');
  }

  hideSpinner() {
    this.Spinner.hide('style-drawer-mobile');
  }

  constructor($q, $scope, Spinner, Snack, $stateParams, contextualDrawer, $location, $timeout,
    gettextCatalog, $rootScope, LabelService, UtilsService, DialogService, StyleService, StateService) {
    'ngInject';

    this.$q = $q;
    this.StyleService = StyleService;
    this.LabelService = LabelService;
    this.UtilsService = UtilsService;
    this.DialogService = DialogService;
    this.contextualDrawer = contextualDrawer;
    this.gettextCatalog = gettextCatalog;
    this.StateService = StateService;
    this.$stateParams = $stateParams;
    this.$location = $location;
    this.$timeout = $timeout;
    this.Spinner = Spinner;
    this.Snack = Snack;
    this.$scope = $scope;
    this.$rootScope = $rootScope;

    this.saveButtonEnabled = false;
    this.drawerKey = 'mobileWallpaper';

    this.venueId = StateService.venue && StateService.venue.id;
    this.channelId = StateService.channel && StateService.channel.id;

    this.styles = [{
      id: this.drawerKey,
      name: gettextCatalog.getString('Splash screen background'),
      height: '165px'
    }, {
      id: 'mobileButtons',
      name: gettextCatalog.getString('Button colour'),
      height: '150px'
    }];

    this.model = {
      images: [],
      colors: {}
    };

    this.init();
  }

  startListenings() {
    const {
      $scope, 
      StyleService, model,
      unRegisterLocationChangeListener,
    } = this;

    const unRegisterColorsListener = $scope.$watch(() => {
      return model.colors;
    }, () => {
      StyleService.updateColorsInReducer(model.colors);
      this.updateSaveButtonState();
    }, true);

    const unRegisterImagesListener = $scope.$watch('$drawer.StyleService.imagesModel',(nv)=>{
      model.images = nv;
    });

    $scope.$on('$destroy', () => {
      // TODO: What is the best way of handling it? 
      // 1 - Restoring the data in the `$destroy` event
      // 2 - Using a separaed reducer prop to handle the editing values
      // Restore the Reducer to the original values
      StyleService.updateColorsInReducer();
      StyleService.updateImagesInReducer();

      unRegisterLocationChangeListener && unRegisterLocationChangeListener();
      unRegisterColorsListener && unRegisterColorsListener();
      unRegisterImagesListener && unRegisterImagesListener();
    });
  }

  init() {
    this.showSpinner();
    this.StyleService.getMobileSettings()
    .then((data)=>{
      this.model.mobileSettings = data ? data : new Preoday.MobileSettings();
      this.model.images = this.StyleService.imagesModel;
      this.model.colors = this.StyleService.colorsModel;

      this.startListenings();

      this._restoreImages();
      this.originalModel = angular.copy(this.model);
      this.hideSpinner();
    }, () => {
      this.startListenings();
      this._restoreImages();
      this.hideSpinner();
    }).catch((err) => {
      this.startListenings();
      console.log("Error fetching Styles -", err)
      this.hideSpinner();
    })

    this.unRegisterLocationChangeListener = this.$rootScope.$on('$locationChangeSuccess', (event) => {
      this.restoreSearch();
    });

    this.restoreSearch();


  }
}
