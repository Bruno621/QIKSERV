export default class contextualDrawerStyleMobileMultiVenueController {
  static get UID() {
    return 'contextualDrawerStyleMobileMultiVenueController';
  }

  _restoreImages() {
    const { StyleService, headerImageName } = this;

    console.log('StyleMobileMultiVenue [_restoreImages] - StyleService.imagesModel', StyleService.imagesModel)

    StyleService.updateImagesForEditingAppMultiVenue(headerImageName);
  }

  saveImagesToCdn() {
    const { StyleService, headerImageName } = this;
    const banners = StyleService.imagesModel.$images.mobileBanner.filter((image) => {
      return image && image.$save;
    });
    const headers = StyleService.imagesModel.$images.mobileHeader.filter((image) => {
      return image && image.$save;
    });
    let promises = banners.map((bannerImage) => {
      // console.log('[saveImagesToCdn] - bannerImage.$image', bannerImage.$image)
      return Preoday.VenueImage.saveToCdn(bannerImage.$image, this.venueId, this.channelId)
        .then((itemImage) => {
          if (StyleService.imagesModel.mobileBanner) {
            angular.extend(StyleService.imagesModel.mobileBanner, {
              src: itemImage.image,
            });
          } else {
            StyleService.imagesModel.mobileBanner = {
              src: itemImage.image,
            };
          }

          this.imageSaved = true;
        });
    });

    promises = promises.concat(headers.map((headerImage) => {
      const imageData = {
        fileName: headerImageName,
        serverPath: 'banner/',
        image: headerImage.$image,
        venueId: this.venueId,
        extensions: ['jpg', 'jpeg', 'png'],
      };
      return Preoday.VenueImage.saveToCdn(imageData)
        .then(() => {
          this.imageSaved = true;
        });
    }));

    if (promises.length === 0) {
      console.warn('Item does not have images');
    }

    return this.$q.all(promises);
  }

  onImageUpload() {
    const { StyleService } = this;

    StyleService.updateImagesInReducer(StyleService.imagesModel.$images);
    this.updateSaveButtonState();
  }

  onImageDelete(key, image) {
    const { 
      StyleService, Snack, 
      Spinner, LabelService, DialogService,
      originalModel, model
    } = this;
    if (key && image) { //only one key here
      DialogService.delete(LabelService.TITLE_DELETE_ITEM_IMAGE, this.LabelService.CONTENT_DELETE_ITEM_IMAGE)
      .then(()=> {
        Spinner.show("venue-image-delete");
        let img = StyleService.imagesModel[key];

        model.mobileSettings.banner = null;
        model.mobileSettings.update()
        .then(() => {
          img.delete()
          .finally(() => {
            StyleService.imagesModel[key] = new Preoday.VenueImage();
            StyleService.imagesModel.$images[key]= [];
            originalModel.images[key] = new Preoday.VenueImage();
            originalModel.images.$images[key]= [];
            StyleService.updateImagesInReducer(StyleService.imagesModel.$images);
            Snack.show(LabelService.IMAGE_DELETE_SUCCESS);
            Spinner.hide("venue-image-delete");
          });
        })
        .catch((err)=>{
          console.log("Failed deleting item image", err)
          Spinner.hide("venue-image-delete")
          Snack.showError(LabelService.IMAGE_DELETE_ERROR);
        });
      });
    }
  }

  saveVenueImages() {
    const { StyleService } = this;
    return this.$q((resolve, reject) => {
      this.saveImagesToCdn()
        .then(() => {
          const $image = StyleService.imagesModel.$images.mobileBanner[0];

          if (!$image || !$image.$save || !StyleService.imagesModel.mobileBanner.src) {
            return resolve();
          }

          const venueImage = StyleService.imagesModel.mobileBanner;

          if (venueImage.id) {
            return venueImage.update();
          }

          venueImage.venueId = this.venueId;
          venueImage.channelId = this.channelId;
          return Preoday.VenueImage.create(venueImage)
            .then((newImg) => {
              angular.extend(venueImage, newImg);
            })
            .then(resolve)
            .catch(reject);
        })
        .catch((err) => {
          console.error('StyleMobileMultiVenue [saveVenueImages] - Error saving Venue IMages - ', err);
          reject(err);
        });
    });
  }

  saveSettings() {
    return this.$q((resolve, reject) => {
      let obj = {
        banner: this.model.images.mobileBanner ? this.model.images.mobileBanner.id : '',
      };
      angular.merge(this.model.mobileSettings, obj);

      if (this.model.mobileSettings.id) {
        this.model.mobileSettings.update()
          .then(resolve, reject)
          .catch((err) => {
            console.error('Error updating Venue Mobile Settings - ', err);
            reject(err);
          });
      } else {

        this.model.mobileSettings.venueId = this.venueId;
        this.model.mobileSettings.channelId = this.channelId;

        Preoday.MobileSettings.save(this.model.mobileSettings)
        .then((newSettings) => {
          angular.extend(this.model.mobileSettings, newSettings);
          angular.extend(this.StyleService.mobileSettings, newSettings);
          this.StyleService.mobileExtendModels(newSettings);
          resolve(newSettings);
        })
        .catch((err)=>{
          console.error('Error saving Venue Mobile Settings - ', err);
          reject(err);
        });
      }

    });
  }

  saveAll() {
    return this.saveVenueImages()
      .then(this.saveSettings.bind(this))
  }

  save() {
    if (this.styleMobileForm.$invalid) {
      return;
    }

    this.showSavingSpinner();
    return this.saveAll().then((data) => {
      this.hideSavingSpinner();

      if (!data.hideSave || this.imageSaved) {
        this.Snack.show(this.LabelService.SNACK_MOBILE_STYLING_SUCCESS)
      }

      this.imageSaved = false;
      this.originalModel = angular.copy(this.model);
      this._restoreImages();
      this.updateSaveButtonState();
    }).catch(() => {
      this.hideSavingSpinner();
      this.Snack.showError(this.LabelService.SNACK_MOBILE_STYLING_ERROR)
    });
  }

  toggleExpanded(style) {
    const { $location, styles } = this;
    if (!style) {
      styles.forEach((s) => { // collapse all
        s.expanded = false;
      });
      return;
    }

    const found = styles.find(i => i.id === style.id);
    if (found && !found.expanded) {
      styles.forEach((i) => { // collapse all
        i.expanded = i.id === style.id;
      });

      $location.search('drawer-mobile-style', found.id);
    }
  }

  restoreSearch() {
    const { UtilsService } = this;
    const drawerStyleParam = UtilsService.getQueryParam('drawer-mobile-style');

    if (drawerStyleParam) {
      this.toggleExpanded({ id: drawerStyleParam });
    } else {
      this.toggleExpanded({ id: 'mobileBanner' });
    }
  }

  shouldEnableSaveButton() {
    const { StyleService, model } = this;
    let hasChanges = false;
    const { $images } = StyleService.imagesModel;

    if (model.images.mobileBanner &&
       (!model.mobileSettings.banner && model.images.mobileBanner.id ||
        model.mobileSettings.banner && !model.images.mobileBanner.id ||
        model.images.mobileBanner.id != model.mobileSettings.banner)) {

      return true;
    }

    if ($images && $images.mobileBanner) {
      // eslint-disable-next-line
      hasChanges = $images.mobileBanner.find((image) => {
        return image && image.$save;
      }) !== undefined;
    }

    if (!hasChanges) {
      if ($images && $images.mobileHeader) {
        // eslint-disable-next-line
        hasChanges = $images.mobileHeader.find((image) => {
          return image && image.$save;
        }) !== undefined;
      }
    }

    return hasChanges;
  }

  updateSaveButtonState() {
    this.saveButtonEnabled = this.shouldEnableSaveButton();
  }

  showSavingSpinner() {
    this.Spinner.show('style-mobile-saving');
  }

  hideSavingSpinner() {
    this.Spinner.hide('style-mobile-saving');
  }

  showSpinner() {
    this.Spinner.show('style-drawer-mobile');
  }

  hideSpinner() {
    this.Spinner.hide('style-drawer-mobile');
  }

  constructor($q, $scope, Spinner, Snack, $stateParams, contextualDrawer, $location, $timeout,
    gettextCatalog, $rootScope, LabelService, UtilsService, DialogService, StyleService, StateService) {
    "ngInject";
    this.$q = $q;
    this.StyleService = StyleService;
    this.LabelService = LabelService;
    this.UtilsService = UtilsService;
    this.DialogService = DialogService;
    this.contextualDrawer = contextualDrawer;
    this.gettextCatalog = gettextCatalog;
    this.StateService = StateService;
    this.$stateParams = $stateParams;
    this.$location = $location;
    this.$timeout = $timeout;
    this.Spinner = Spinner;
    this.Snack = Snack;
    this.$scope = $scope;
    this.$rootScope = $rootScope;

    this.saveButtonEnabled = false;

    this.venueId = StateService.venue && StateService.venue.id;
    this.channelId = StateService.channel && StateService.channel.id;

    this.headerImageName = `header-${this.venueId}.jpg`;

    this.styles = [{
      id: 'mobileBanner',
      name: gettextCatalog.getString('List Screen banner'),
      height: '165px',
    }, {
      id: 'mobileHeader',
      name: gettextCatalog.getString('Venue Details banner'),
      height: '165px',
    }];

    this.model = {
      images: [],
    };

    this.init();
  }

  init() {
    this.showSpinner();
    this.StyleService.getMobileSettings()
      .then((data) => {
        this.model.mobileSettings = data || new Preoday.MobileSettings();
        this.model.images = this.StyleService.imagesModel;

        this.$scope.$watch('$drawer.StyleService.imagesModel', (nv)=>{
          this.model.images = nv;
        })

        this._restoreImages();
        this.originalModel = angular.copy(this.model);
        this.hideSpinner();
      }, () => { 
        this._restoreImages();
        this.hideSpinner();
      })
      .catch((err) => {
        console.log("Error fetching Styles -", err)
        this.hideSpinner();
      });

    const unRegisterLocationListener = this.$rootScope.$on('$locationChangeSuccess', (event)=>{
      this.restoreSearch();
    });

    this.restoreSearch();

    this.$scope.$on('$destroy', () => {
      // TODO: What is the best way of handling it? 
      // 1 - Restoring the data in the `$destroy` event
      // 2 - Using a separaed reducer prop to handle the editing values
      // Restore the Reducer to the original values      
      this.StyleService.updateImagesInReducer();

      unRegisterLocationListener && unRegisterLocationListener();
    });
  }
}
