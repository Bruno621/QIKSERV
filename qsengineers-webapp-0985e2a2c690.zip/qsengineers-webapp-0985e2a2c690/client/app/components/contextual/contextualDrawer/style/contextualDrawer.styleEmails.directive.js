import controller from './contextualDrawer.styleEmails.controller';

export default function contextualMenu() {
  'ngInject';

  return {
    restrict: 'E',
    replace: true,
    bindToController: true,
    controller: controller.UID,
    controllerAs: 'drawerStyleEmailsCtrl',
    template: require('./contextualDrawer.styleEmails.tpl.html')
  };
}
