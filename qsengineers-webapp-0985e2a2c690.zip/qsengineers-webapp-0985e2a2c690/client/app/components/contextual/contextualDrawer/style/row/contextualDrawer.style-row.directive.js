// Import styles
import './contextualDrawer.style-row.scss';

export default function contextualMenu($compile) {
  'ngInject';
  return {
    restrict: 'E',
    replace: true,
    transclude: true,
    require: [
      '?^contextualDrawerStyle',
      '?^contextualDrawerStyleEmails',
      '?^contextualDrawerStyleMobile',
      '?^contextualDrawerStyleMobileMultiVenue',
      '?^contextualDrawerStylePayAtTable',
      '?^contextualDrawerStyleLoyalty'
    ],
    scope: {
      entity: '=',
      model: '=',
      formCtrl: '='
    },
    link: postLink,
    template: require('./contextualDrawer.style-row.tpl.html')
  };

  function postLink(scope, el, attr, ctrls) {
    var ctrl = ctrls[0] || ctrls[1] || ctrls[2] || ctrls[3] || ctrls[4] || ctrls[5];
    scope.toggleAccordion = ctrl.toggleExpanded.bind(ctrl);

    let $template = require('./templates/' + scope.entity.id + '.tpl.html');
    let $templateEl = $compile($template)(scope);

    // Compile sections into wrapper tpl
    let wrapper = angular.element(el[0].querySelector('.form-style'));
    wrapper.prepend($templateEl);

    function recalcHeight(newVal, oldVal) {
      if (newVal && !oldVal) {
        if (scope.radioChoice) {
          wrapper.css('height', scope.entity.height[scope.radioChoice]);
        } else {
          wrapper.css('height', scope.entity.height);
        }
      } else if (!newVal && oldVal) {
        wrapper.css('height', 0);
      }
    }

    scope.$watch('radioChoice', (newVal, oldVal) => {
      if (scope.entity.expanded) {
        recalcHeight(true, false);
      }
    });

    scope.$watch('entity.expanded', (newVal, oldVal) => {
      console.log('[ContextualDrawerStyleRow] recalc height:', newVal, oldVal);
      recalcHeight(newVal, oldVal);
    });

    scope.onChange = (key, imageModel) => {
      ctrl.onImageUpload(key, imageModel);
    };

    scope.onDelete = (key, imageModel) => {
      if (ctrl.onImageDelete){
        ctrl.onImageDelete(key, imageModel);
      }
    };
  }
}
