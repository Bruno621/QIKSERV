import controller from './contextualDrawer.styleMobile.controller';

export default function contextualMenu() {
  'ngInject';

  return {
    restrict: 'E',
    replace: true,
    bindToController: true,
    controller: controller.UID,
    controllerAs: '$drawer',
    template: require('./contextualDrawer.styleMobile.tpl.html')
  };
}
