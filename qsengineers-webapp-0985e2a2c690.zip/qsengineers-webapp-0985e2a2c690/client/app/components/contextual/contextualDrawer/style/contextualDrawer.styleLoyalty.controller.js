export default class ContextualDrawerLoyaltyController {
  static get UID() {
    return 'ContextualDrawerStyleLoyalty';
  }

  onSave() {
    const {LabelService, Spinner, Snack, styleLoyaltyForm, LOADER_KEY} = this;

    if (styleLoyaltyForm.$invalid) {
      return;
    }

    Spinner.show(LOADER_KEY);

    this.onSaveImageToCDN()
      .then(this.onSaveStyling.bind(this), err => {
        // Hide spinner and display the message for upload error
        Spinner.hide(LOADER_KEY);
        Snack.showError(LabelService.SNACK_LOYALTY_ERROR_UPLOAD);
      });
  }

  onSaveStyling() {
    const {LoyaltyService, LabelService, Spinner, Snack, originalModel, LOADER_KEY} = this;

    LoyaltyService.saveStyling()
      .then(data => {
        // UPDATE model data and close the drawer
        angular.extend(originalModel, data);
        Snack.show(LabelService.SNACK_LOYALTY_SUCCESS);
        this.onClose();
      }).catch(err => {
        Snack.showError(LabelService.SNACK_LOYALTY_ERROR);
      }).finally(() => {
        Spinner.hide(LOADER_KEY);
      });
  }

  onSaveImageToCDN() {
    const {model, campaign, $q} = this;

    const backgroundImage = (model.$background || []).find(image => {
      return image.$image;
    });

    if (!backgroundImage || !backgroundImage.$save) {
      return $q.resolve();
    }

    const deferred = $q.defer();

    backgroundImage.channelId = campaign.channelId;
    backgroundImage.venueId = campaign.venueId;
    backgroundImage.image = backgroundImage.$image;
    backgroundImage.serverPath = 'loyalty/';

    Preoday.VenueImage.saveToCdn(backgroundImage)
      .then(image => {
        // Extend the `backgroundImage` prop with the source url
        angular.extend(backgroundImage, image);
        angular.extend(model, {
          backgroundImage: image.image
        });

        deferred.resolve();
      }, deferred.reject);

    return deferred.promise;
  }

  onClose() {
    const {$timeout, contextualDrawer, model, originalModel} = this;
    // restore the original values
    angular.extend(model, originalModel);
    this.onRestoreImage();

    $timeout(this.toggleExpanded.bind(this));
    return contextualDrawer.close();
  }

  onRestoreSearch() {
    const {$location} = this;

    const index = $location.search()['drawer-loyalty-style'];
    if (index) {
      this.toggleExpanded({id: index})
    }
  }

  onRestoreImage() {
    const {UtilsService, model} = this;

    model.$background = model.backgroundImage ? [{
      id: model.loyaltyCampaignId,
      image: model.backgroundImage,
      $image: UtilsService.getImagePath(model.backgroundImage)
    }] : [];
  }

  onImageDelete() {
    this.model.$background = [];
    this.model.backgroundImage = null;
  }

  toggleExpanded(style) {
    if (!style) {
      return this.styles.forEach(_style => {
        _style.expanded = false;
      });
    }

    const match =  this.styles.find(_style => _style.id === style.id);

    if (match && !match.expanded) {
      this.styles.forEach(_style => {
        _style.expanded = _style.id === style.id;
      });
    }
  }

  constructor(LoyaltyService, LabelService, UtilsService, $rootScope, $q, $location, $timeout, Spinner, Snack, contextualDrawer, gettextCatalog) {
    'ngInject';
    // Dependencies
    this.LoyaltyService = LoyaltyService;
    this.LabelService = LabelService;
    this.UtilsService = UtilsService;
    this.$q = $q;
    this.$location = $location;
    this.$timeout = $timeout;
    this.Spinner = Spinner;
    this.Snack = Snack;
    this.contextualDrawer = contextualDrawer;

    // DEFAULTS
    this.LOADER_KEY = 'style-loyalty-saving';

    this.styles = [{
      id: 'LOYALTY-BACKGROUND',
      name: gettextCatalog.getString('Background'),
      height: {
        color: '160px',
        image: '230px'
      }
    }, {
      id: 'LOYALTY-STAMPS',
      name: gettextCatalog.getString('Stamps'),
      height: '80px'
    }, {
      id: 'LOYALTY-TEXT-COLOR',
      name: gettextCatalog.getString('Text colour'),
      height: '80px'
    }];

    // SET data models
    this.model = LoyaltyService.styling;
    this.campaign = LoyaltyService.campaign;
    this.onRestoreImage();

    // COPY the original model
    this.originalModel = angular.copy(this.model);

    $rootScope.$on('$locationChangeSuccess', this.onRestoreSearch.bind(this));
    this.onRestoreSearch();
  }
}
