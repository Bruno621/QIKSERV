// Import Style
import './contextualMenu.scss';


// Import internal modules
import controller from './contextualMenu.controller';
import service from './contextualMenu.service';
import contextualMenuValidation from './contextualMenuValidation.service';
import directive from './contextualMenu.directive';
import holderDirective from './contextualMenuHolder.directive';

import menuItemBasic from './components/menuItemBasic';
import menuItemSize from './components/menuItemSize';
import modifierItems from './components/modifierItems';
import modifierSelection from './components/modifierSelection';
import menusSelect from './components/menusSelect';
import collectionSlotBasic from './components/collectionSlotBasic';
import collectionSlotAdvanced from './components/collectionSlotAdvanced';
import collectionSlotsSelect from './components/collectionSlotsSelect';
import eventBasic from './components/eventBasic';
import eventScheduleForm from './components/eventScheduleForm';
import taxGroupSelect from './components/taxGroupSelect';
import taxGroupForm from './components/taxGroupForm';
import menuItemAdvanced from './components/menuItemAdvanced';
import menuItemMore from './components/menuItemMore';
import userRoleSelect from './components/userRoleSelect';
import promotionComponents from './components/promotionComponents';
import customTagForm from './components/customTagForm';
import tagActionBasic from './components/tagActionBasic';
import tagActionAdvanced from './components/tagActionAdvanced';
import tagSelect from './components/tagSelect';
import inviteDetails from './components/inviteDetails';
import userDetails from './components/userDetails';
import applicationSelect from './components/applicationSelect';
import marketingCheckbox from './components/marketingCheckbox';
import sectionComponents from './components/sectionComponents';
import menuComponents from './components/menuComponents';

import modifierComponents from './components/modifierComponents';
import venueGroupComponents from './components/venueGroupComponents';

import awardComponents from './components/awardComponents';

import services from 'app/shared';
import validNumber from 'app/components/validNumber';
import validPrice from 'app/components/validPrice';
import validPercentage from 'app/components/validPercentage';
import validHtml from 'app/components/validHtml';
import validHexcolor from 'app/components/validHexcolor';
import maxIntegerValue from 'app/components/maxIntegerValue';
import minIntegerValue from 'app/components/minIntegerValue';
import compareNumber from 'app/components/compareNumber';
import venueCurrency from 'app/components/venueCurrency';

// React module
import ReactModule from 'app/react/index.angular';

// React components
import EntitySelect from 'app/react/components/EntitySelect/EntitySelect.angular.module';

export default angular.module("contextualMenu" , [
	menuItemBasic,
	menuItemSize,
	menusSelect,
	modifierItems,
	modifierSelection,
	collectionSlotBasic,
	collectionSlotAdvanced,
	collectionSlotsSelect,
	eventBasic,
  	eventScheduleForm,
	taxGroupSelect,
	taxGroupForm,
	menuItemAdvanced,
	menuItemMore,
	userRoleSelect,
	services,
	validNumber,
  	validPrice,
	validPercentage,
	validHtml,
	validHexcolor,
	maxIntegerValue,
	minIntegerValue,
	compareNumber,
  	promotionComponents,
	customTagForm,
	tagActionBasic,
	tagActionAdvanced,
	tagSelect,
	inviteDetails,
	userDetails,
	applicationSelect,
	marketingCheckbox,
	venueCurrency,
  	sectionComponents,
	menuComponents,
  	modifierComponents,
	venueGroupComponents,
	awardComponents,
  	ReactModule,
  	EntitySelect,
])
  .controller(controller.UID, controller)
  .service(service.UID, service)
  .service(contextualMenuValidation.UID, contextualMenuValidation)
  .directive("contextualMenu", directive)
  .directive("contextualMenuHolder", holderDirective)
  .name;
