export default class contextualMenuController {
  static get UID() {
    return 'contextualMenuController';
  }

  // restore original state if user cancels
  doCancel() {
    console.log('contextualMenuController [doCancel]');

    if (this.onCancel) {
      this.onCancel();
    } else {
      this.contextualMenu.reject();
    }
  }

  doSubmit() {
    if (this.params && angular.isFunction(this.params.onBeforeSubmit)) {
      this.params.onBeforeSubmit.call(this);
    } else {
      this.onSubmit();
    }
  }

  onSubmit() {
    // we are using a custom submitted flag because we has pre-submit functions,
    // and we don't want to set the $submitted flag to true when call the onBeforeSubmit function
    this.contextualForm.submitted = true;
    if (this.contextualForm.$valid) {

      if (this.params && angular.isFunction(this.params.onBeforeSuccess)) {
        this.params.onBeforeSuccess.call(this);
      } else {
        this._complete();
      }
    } else {
      // this is to the child directive redirect to error tab for example.
      this.$scope.$broadcast(this.BroadcastEvents.ON_CONTEXTUAL_FORM_SUBMITTED);
    }
  }

  _complete() {
    if (this.onSuccess) {
      this.onSuccess({
        entity: this.entity,
      });
    } else {
      this.contextualMenu.resolve(this.entity);
    }
  }

  getImage() {
    if (this.entity && this.entity.images && this.entity.images.length) {
      const path = this.UtilsService.getImagePath(this.entity.images[0].image);
      return path;
    }

    return false;
  }

  isShowing(type) {
    return this.contextualMenu.type === type;
  }

  getButtonName() {
    if (this.params && this.params.doneButtonText) {
      if (angular.isFunction(this.params.doneButtonText)) {
        return this.params.doneButtonText.call(this);
      }

      return this.params.doneButtonText;
    }

    return this.gettextCatalog.getString('Done');
  }

  constructor($scope, $stateParams, UtilsService, contextualMenu, MenuService, FeatureService, ContextualMenuValidationService, ItemService, ModifierService, $timeout, BroadcastEvents, StateService, gettextCatalog,
    PermissionService, Permissions) {
    'ngInject';

    console.log('ContexturalMenuController - Showing conextual menu ', this.entity, this.type);

    this.$scope = $scope;
    this.$timeout = $timeout;
    this.$stateParams = $stateParams;
    this.UtilsService = UtilsService;
    this.originalEntity = angular.copy(this.entity);
    this.contextualMenu = contextualMenu;
    this.MenuService = MenuService;
    this.FeatureService = FeatureService;
    this.ValidationService = ContextualMenuValidationService;
    this.ItemService = ItemService;
    this.ModifierService = ModifierService;
    this.BroadcastEvents = BroadcastEvents;
    this.StateService = StateService;
    this.gettextCatalog = gettextCatalog;

    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature();
    this.hasMenuItemExternalIdFeature = FeatureService.hasMenuItemExternalIdFeature();
    this.hasHideAllergenTagsFeature = FeatureService.hasHideAllergenTagsFeature();
    this.hasKioskMenuContentFeature = FeatureService.hasKioskMenuContentFeature();

    this.hasMenuCreatePermission = PermissionService.hasPermission(Permissions.MENU_CREATE);

    const UPLOAD_SECTION_IMAGE_SIZE = { w: 830, h: 260 };
    const UPLOAD_SECTION_IMAGE_GAP = 25;
    const KIOSK_UPLOAD_SECTION_IMAGE_SIZE = { w: 286, h: 270 };

    const UPLOAD_ITEM_IMAGE_SIZE = { w: 590, h: 393 };
    const UPLOAD_ITEM_IMAGE_GAP = 25;
    const KIOSK_UPLOAD_ITEM_IMAGE_SIZE = { w: 1000, h: 1000 };

    this.sectionImageUploaderParams = this.hasKioskMenuContentFeature
      ? {
        viewport: KIOSK_UPLOAD_SECTION_IMAGE_SIZE,
        boundry: {
          w: KIOSK_UPLOAD_SECTION_IMAGE_SIZE.w + UPLOAD_SECTION_IMAGE_GAP,
          h: KIOSK_UPLOAD_SECTION_IMAGE_SIZE.h + UPLOAD_SECTION_IMAGE_GAP,
        },
        output: KIOSK_UPLOAD_SECTION_IMAGE_SIZE,
        dimensions: `${KIOSK_UPLOAD_SECTION_IMAGE_SIZE.w} x ${KIOSK_UPLOAD_SECTION_IMAGE_SIZE.h}`,
      }
      : {
        viewport: UPLOAD_SECTION_IMAGE_SIZE,
        boundry: {
          w: UPLOAD_SECTION_IMAGE_SIZE.w + UPLOAD_SECTION_IMAGE_GAP,
          h: UPLOAD_SECTION_IMAGE_SIZE.h + UPLOAD_SECTION_IMAGE_GAP,
        },
        output: UPLOAD_SECTION_IMAGE_SIZE,
        dimensions: `${UPLOAD_SECTION_IMAGE_SIZE.w} x ${UPLOAD_SECTION_IMAGE_SIZE.h}`,
      };

    this.itemImageUploadParameters = this.hasKioskMenuContentFeature
      ? {
        viewport: KIOSK_UPLOAD_ITEM_IMAGE_SIZE,
        boundry: {
          w: KIOSK_UPLOAD_ITEM_IMAGE_SIZE.w + UPLOAD_ITEM_IMAGE_GAP,
          h: KIOSK_UPLOAD_ITEM_IMAGE_SIZE.h + UPLOAD_ITEM_IMAGE_GAP,
        },
        output: KIOSK_UPLOAD_ITEM_IMAGE_SIZE,
        dimensions: `${KIOSK_UPLOAD_ITEM_IMAGE_SIZE.w} x ${KIOSK_UPLOAD_ITEM_IMAGE_SIZE.h}`,
      }
      : {
        viewport: UPLOAD_ITEM_IMAGE_SIZE,
        boundry: {
          w: UPLOAD_ITEM_IMAGE_SIZE.w + UPLOAD_ITEM_IMAGE_GAP,
          h: UPLOAD_ITEM_IMAGE_SIZE.h + UPLOAD_ITEM_IMAGE_GAP,
        },
        output: UPLOAD_ITEM_IMAGE_SIZE,
        dimensions: `${UPLOAD_ITEM_IMAGE_SIZE.w} x ${UPLOAD_ITEM_IMAGE_SIZE.h}`,
      };
  }
}
