
// Import internal modules
import awardForm from './awardForm';

export default angular.module('awardComponents', [
  awardForm,
])
  .name;
