
// Import Style
import './sectionParentSelection.scss';

// Import internal modules
import controller from './sectionParentSelection.controller';
import directive from './sectionParentSelection.directive';

export default angular.module('sectionParentSelection', [])
  .controller(controller.UID, controller)
  .directive('sectionParentSelection', directive)
  .name;
