// Import Style
import './venueGroupBasic.scss';

// Import internal modules
import VenueGroupBasicController from './venueGroupBasic.controller';
import VenueGroupBasicComponent from './venueGroupBasic.component';

export default angular.module('venueGroupBasic', [])
  .controller(VenueGroupBasicController.UID, VenueGroupBasicController)
  .component('venueGroupBasic', VenueGroupBasicComponent)
  .name;
