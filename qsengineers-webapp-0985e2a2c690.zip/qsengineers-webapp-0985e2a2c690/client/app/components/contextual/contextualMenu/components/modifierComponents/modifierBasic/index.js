
// Import Style
import './modifierBasic.scss';

// Import internal modules
import ModifierBasicController from './modifierBasic.controller';
import ModifierBasicComponent from './modifierBasic.component';

export default angular.module('modifierBasic', [])
  .controller(ModifierBasicController.UID, ModifierBasicController)
  .component('modifierBasic', ModifierBasicComponent)
  .name;
