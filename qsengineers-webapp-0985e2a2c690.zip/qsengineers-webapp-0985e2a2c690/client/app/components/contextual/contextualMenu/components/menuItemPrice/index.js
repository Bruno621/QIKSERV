
// Import Style
import './menuItemPrice.scss';

// Import internal modules
import MenuItemPriceController from './menuItemPrice.controller';
import MenuItemPriceComponent from './menuItemPrice.component';

import ModifierItemsComponent from '../modifierItems';
import ModifierItemsPackComponent from '../modifierItemsPack';

export default angular.module('menuItemPrice', [
  // component dependencies
  ModifierItemsComponent,
  ModifierItemsPackComponent
]).controller(MenuItemPriceController.UID, MenuItemPriceController)
  .component('menuItemPrice', MenuItemPriceComponent)
  .name;
