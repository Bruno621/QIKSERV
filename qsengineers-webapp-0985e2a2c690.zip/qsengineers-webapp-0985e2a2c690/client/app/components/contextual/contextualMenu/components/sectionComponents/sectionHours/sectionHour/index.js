
// Import Style
import './sectionHour.scss';

// Import internal modules
import controller from './sectionHour.controller';
import directive from './sectionHour.directive';

export default angular.module('sectionHour', [])
  .controller(controller.UID, controller)
  .directive('sectionHour', directive)
  .name;
