export default class userDetailsController {
  static get UID(){
    return "userDetailsController"
  }

  constructor() {
    "ngInject";

  }
}
