
export default class venueGroupBasicController {
  static get UID() {
    return 'venueGroupBasicController';
  }
}
