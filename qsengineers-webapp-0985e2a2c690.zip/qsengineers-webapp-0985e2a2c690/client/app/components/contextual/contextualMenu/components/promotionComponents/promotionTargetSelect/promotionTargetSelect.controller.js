export default class promotionTargetSelectController {
  static get UID() {
    return "promotionTargetSelectController"
  }

  onSearch(query) {

    const {StateService} = this;

    switch (this.target) {
      case this.PromotionTarget.ITEM:
        return Preoday.Item.getAll({
          venueId: StateService.venue && StateService.venue.id,
          channelId: StateService.channel && StateService.channel.id,
          q: query,
          limit: this.resultsLimit
        });
        break;
      case this.PromotionTarget.SECTION:
        return Preoday.Section.getAll({
          venueId: StateService.venue && StateService.venue.id,
          channelId: StateService.channel && StateService.channel.id,
          q: query,
          limit: this.resultsLimit
        });
        break;
      case this.PromotionTarget.TAG:
        if (StateService.channel) {
          return Preoday.CustomTag.searchByChannelId(StateService.channel && StateService.channel.id, query, this.resultsLimit);
        }

        return Preoday.CustomTag.searchByVenueId(StateService.venue && StateService.venue.id, query, this.resultsLimit);
        break;
    }
  }

  onNotFound(query) {
    console.log('promotionTargetSelectController [onNotFound] - query', query);
  }

  getPlaceholder() {
    const {gettextCatalog, PromotionTarget} = this;

    switch (this.target) {
      case PromotionTarget.ITEM:
        return gettextCatalog.getString('Type item name…');
        break;
      case PromotionTarget.SECTION:
        return gettextCatalog.getString('Type section name…');
        break;
      case PromotionTarget.TAG:
        return gettextCatalog.getString('Type tag name…');
        break;
    }
  }

  constructor(gettextCatalog, PromotionTarget, StateService) {
    "ngInject";

    this.StateService = StateService;
    this.PromotionTarget = PromotionTarget;
    this.gettextCatalog = gettextCatalog;

    this.notFoundText = gettextCatalog.getString('No results for');
    this.resultsLimit = 20;
  }
}
