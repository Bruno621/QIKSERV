// Import Style
import './customTagForm.scss';


// Import internal modules
import controller from './customTagForm.controller';
import directive from './customTagForm.directive';



export default angular.module("customTagForm" , [])

  .controller(controller.UID, controller)
  .directive("customTagForm", directive)
  .name;
