import Availability from 'app/shared/constants/itemAvailabilityType.constants';


export default class modifierItemsController {
  static get UID() {
    return 'modifierItemsController';
  }

  constructor($scope, $state, gettextCatalog, FeatureService, StateService, DialogService, ModifierService,
    PermissionService, Permissions, Spinner, Snack) {
    'ngInject';

    this.$scope = $scope;
    this.$state = $state;
    this.gettextCatalog = gettextCatalog;
    this.DialogService = DialogService;
    this.ModifierService = ModifierService;
    this.Spinner = Spinner;
    this.Snack = Snack;

    this.modifier.$deletedItems = [];
    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature();
    this.hasMenuItemExternalIdFeature = FeatureService.hasMenuItemExternalIdFeature();
    this.hasManualSkuFeature = FeatureService.hasManualSkuFeature();
    this.hasOutOfStockFeature = FeatureService.hasOutOfStockFeature();
    this.disableIfExternalMenusFeature = FeatureService.hasExternalMenusFeature() && !StateService.isChannel;
    this.hasCaloriesInformationFlag = FeatureService.hasCaloriesInformationFlag();
    this.hasKioskMenuContentFeature = FeatureService.hasKioskMenuContentFeature();

    this.hasStockCreatePermission = PermissionService.hasPermission(Permissions.STOCK_MANAGER);
    this.hasMenuCreatePermission = PermissionService.hasPermission(Permissions.MENU_CREATE);

    this.maxIntegerValue = 32766;
  }

  $onInit() {
    const { modifier } = this;

    this.options = angular.extend(this.getDefaultOptions(), this.options || {});

    if (!modifier.items.length) {
      for (let length = this.options.minLength; length--;) {
        modifier.items.push(this.getEmptySize());
      }
    }
  }

  getDefaultOptions() {
    const { gettextCatalog } = this;

    return {
      hideOptionTooltip: gettextCatalog.getString('Hide option from modifier'),
      showOptionTooltip: gettextCatalog.getString('Show modifier option'),
      optionFieldLabel: gettextCatalog.getString('Internal option name'),
      optionFieldDisplayLabel: gettextCatalog.getString('Option display name'),
      addOptionLabel: gettextCatalog.getString('Add option'),
      minLength: 1,
      sortable: false,
      editable: true,
      priceProperty: 'price',
      formName: 'itemForm',
    };
  }

  deleteItem(itemToRemove) {
    this.modifier.$deletedItems = this.modifier.$deletedItems.concat(this.modifier.items.filter(item => item === itemToRemove));
    this.modifier.items = this.modifier.items.filter(item => item !== itemToRemove);

    this.modifier.items.map((item, index) => {
      item.position = index * 1000;
      return item;
    });

    this.modifier.setVisible();
  }

  addOption() {
    this.modifier.items.push(this.getEmptySize());

    this.onAddOption && this.onAddOption({
      modifier: this.modifier,
    });
  }

  toggleDefault(size) {
    if (size.defaultQuantity === 0) {return;}

    for (let i = 0; i < this.modifier.items.length; i++) {
      this.modifier.items[i].defaultQuantity = 0;
    }

    size.defaultQuantity = 1;
  }

  getEmptySize() {
    const { modifier } = this;

    return new Preoday.ModifierItem({
      visible: 1,
      position: (modifier.items.length * 1000),
      price: 0,
      maxChoices: 1,
      defaultQuantity: 0,
      available: true,
      availabilityType: Availability.AVAILABLE_NOW,
    });
  }

  onVisibilityClick(item, isVisible) {
    if (this.onVisibility) {
      this.onVisibility({
        modifierItem: item,
        isVisible,
      });
      return;
    }

    item.visible = isVisible;
    this.modifier.setVisible();
  }

  getNotAvailableText(item) {
    const { ModifierService } = this;

    return ModifierService.getNotAvailableText(item);
  }

  updateItemAvailableDate(data, item) {
    const {
      ModifierService,
      Spinner,
      Snack,
      gettextCatalog,
    } = this;
    const LOADER_KEY = 'modifier-item-update-availability';

    const { availabilityType, availableDate } = data;

    item.availabilityType = availabilityType;
    item.availableDateLong = moment(availableDate).valueOf();

    Spinner.show(LOADER_KEY);

    ModifierService.updateAvailableDate(item)
      .then((updatedItem) => {
        item.available = updatedItem.available;
        item.availableDate = updatedItem.availableDate;

        Snack.show(gettextCatalog.getString('Modifier item saved'));
      })
      .catch(() => {
        Snack.showError(gettextCatalog.getString('Modifier item avaiability date not changed'));
      })
      .finally(() => {
        Spinner.hide(LOADER_KEY);
      });
  }

  onItemAvailabilityClick(item) {
    const { DialogService } = this;

    const data = {
      availabilityType: item.availabilityType,
      availableDate: null,
    };

    if (item.availabilityType === Availability.CUSTOM_DATE) {
      data.availableDate = new Date(item.availableDate);
    }

    const templateString = require('app/components/dialog/dialog.itemAvailability.tpl.html');

    DialogService.showItemAvailability(data, templateString)
      .then(({
        availabilityType,
        availableDate,
      }) => {
        this.updateItemAvailableDate({
          availabilityType,
          availableDate,
        }, item);
      });
  }

  shouldShowOutOfStock() {
    return this.hasOutOfStockFeature && this.hasStockCreatePermission;
  }

  shouldShowDeleteOption() {
    return this.options.editable
      && !this.disableIfExternalMenusFeature
      && this.modifier.items.length > this.options.minLength
      && this.hasMenuCreatePermission;
  }
}
