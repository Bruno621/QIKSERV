
// Controller
import ModifierBasicController from './modifierBasic.controller';

const ModifierBasicComponent = {
  bindings: {
    modifier: '<',
    params: '<?',
  },
  require: {
    contextualForm: '^^form',
  },
  controller: ModifierBasicController,
  controllerAs: '$modifierBasic',
  template: require('./modifierBasic.tpl.html'),
};

export default ModifierBasicComponent;
