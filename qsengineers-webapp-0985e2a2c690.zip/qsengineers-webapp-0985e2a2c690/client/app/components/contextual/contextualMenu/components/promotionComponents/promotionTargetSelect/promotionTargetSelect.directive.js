
import controller from './promotionTargetSelect.controller'

export default function promotionTargetSelect(){
  "ngInject";
  return {
    restrict: 'E',
    scope: {
      ngModel: "=",
      target: "=",
    },
    template: require("./promotionTargetSelect.tpl.html"),
    replace: true,
    controller: controller.UID,
    controllerAs: "$promotionTargetSelect",
    bindToController: true,
    link: (scope, el, attr, ctrl) => {

    }
  }
}
