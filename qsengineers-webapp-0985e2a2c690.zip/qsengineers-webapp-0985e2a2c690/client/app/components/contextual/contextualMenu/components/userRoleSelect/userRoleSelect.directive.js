import controller from './userRoleSelect.controller'

export default function userRoleSelect(FeatureService){
  "ngInject";
  return {
    restrict: 'E',
    scope: {
      ngModel: '=',
      allRoles: '='
    },
    template: function () {
      if (FeatureService.hasAdvancedRoles()){
        return require("./userRoleSelect.advanced.tpl.html");
      } else {
        return require("./userRoleSelect.tpl.html");
      }
    },
    replace: true,
    controller: controller.UID,
    controllerAs: "userRoleSelectCtrl",
    bindToController: true,
    link: (scope, el, attr, ctrl) => {

    }
  }
}
