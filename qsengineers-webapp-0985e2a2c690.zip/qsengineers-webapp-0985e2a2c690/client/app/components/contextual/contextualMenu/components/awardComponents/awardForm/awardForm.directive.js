
import controller from './awardForm.controller';

export default function awardForm() {
  return {
    restrict: 'E',
    scope: {
      promotion: '=',
    },
    template: require('./awardForm.tpl.html'),
    controller: controller.UID,
    controllerAs: '$award',
    bindToController: true,
    require: ['^form', 'awardForm'],
    link: (scope, el, attr, ctrls) => {
      ctrls[1].contextualForm = ctrls[0];
    },
  };
}
