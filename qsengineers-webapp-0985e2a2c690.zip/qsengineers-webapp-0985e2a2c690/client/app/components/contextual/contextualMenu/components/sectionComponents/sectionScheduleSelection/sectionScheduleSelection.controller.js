
export default class sectionScheduleSelectionController {
  static get UID() {
    return 'sectionScheduleSelectionController';
  }

  constructor() {
    'ngInject';
  }
}
