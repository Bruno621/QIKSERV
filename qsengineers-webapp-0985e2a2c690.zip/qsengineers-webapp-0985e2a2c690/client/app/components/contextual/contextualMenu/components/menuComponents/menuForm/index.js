// Import internal modules
import controller from './menuForm.controller';
import directive from './menuForm.directive';

export default angular.module("menuForm", [])

  .controller(controller.UID, controller)
  .directive("menuForm", directive)
  .name;
