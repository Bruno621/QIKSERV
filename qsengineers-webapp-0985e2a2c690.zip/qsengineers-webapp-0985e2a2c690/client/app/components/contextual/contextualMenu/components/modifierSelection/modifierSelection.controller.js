export default class modifierSelectionController {
  static get UID(){
    return "modifierSelectionController"
  }

  onSelectionSelect(){
    this.modifier.minChoices = this.modifier.$isOptional ? 0 : 1;
    this.minIntegerValue = this.modifier.$isOptional ? 0 : 1;
  }

  constructor(Spinner, FeatureService, StateService) {
    "ngInject";

    this.Spinner = Spinner;
    this.hasManualSkuFeature = FeatureService.hasManualSkuFeature();
    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature() && !StateService.isChannel;
    this.hasKioskMenuContentFeature = FeatureService.hasKioskMenuContentFeature();

    this.modifier.$isOptional = this.modifier.minChoices === 0 ;

    if (this.modifier.maxChoices === -1) {
      this.modifier.maxChoices = '';
    }

    this.maxIntegerValue = 32766;
    this.minIntegerValue = this.modifier.$isOptional ? 0 : 1;
  }
}
