
import controller from './menuItemSize.controller';

export default function menuItemSize() {
  return {
    restrict: 'E',
    template: require('./menuItemSize.tpl.html'),
    controller: controller.UID,
    scope: {
      ngSinglePriceModel: '=',
      modifier: '=',
      item: '=',
      disabled: '=?',
    },
    controllerAs: 'menuItemSizeCtrl',
    bindToController: true,
  };
}
