// Import internal modules
import venueGroupBasic from './venueGroupBasic';
import venueGroupAdvanced from './venueGroupAdvanced';

export default angular.module('venueGroupComponents', [
  venueGroupBasic,
  venueGroupAdvanced
]).name;
