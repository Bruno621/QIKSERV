
export default class modifierItemsPackController {
  static get UID() {
    return 'modifierItemsPackController';
  }

  constructor(gettextCatalog, FeatureService) {
    'ngInject';

    this.gettextCatalog = gettextCatalog;

    this.modifier.$deletedItems = [];
    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature();
    this.hasMenuItemExternalIdFeature = FeatureService.hasMenuItemExternalIdFeature();
    this.hasManualSkuFeature = FeatureService.hasManualSkuFeature();
  }

  $onInit() {
    const {modifier} = this;

    this.options = angular.extend(this.getDefaultOptions(), this.options || {});

    if (!modifier.items.length) {
      for (let length = this.options.minLength; length--;) {
        modifier.items.push(this.getEmptySize());
      }
    }
  }

  getDefaultOptions() {
    const {gettextCatalog} = this;

    return {
      hideOptionTooltip: gettextCatalog.getString('Hide option from modifier'),
      showOptionTooltip: gettextCatalog.getString('Show modifier option'),
      optionFieldLabel: gettextCatalog.getString('Internal option name'),
      optionFieldDisplayLabel: gettextCatalog.getString('Option display name'),
      addOptionLabel: gettextCatalog.getString('Add option'),
      minLength: 1,
      sortable: false,
      editable: true,
      formName: 'itemForm',
    };
  }

  getEmptySize() {
    const {modifier} = this;

    return new Preoday.ModifierItem({
      visible: 1,
      position: (modifier.items.length * 1000),
      price: 0,
      maxChoices: 1,
      defaultQuantity: 1,
    });
  }

  deleteItem(item) {
    this.modifier.$deletedItems = this.modifier.$deletedItems.concat(this.modifier.items.filter(o => o == item));
    this.modifier.items = this.modifier.items.filter(o => o != item);

    this.modifier.setVisible();
  }

  addOption() {
    this.modifier.items.push(this.getEmptySize());

    this.onAddOption && this.onAddOption({
      modifier: this.modifier,
    });
  }
}
