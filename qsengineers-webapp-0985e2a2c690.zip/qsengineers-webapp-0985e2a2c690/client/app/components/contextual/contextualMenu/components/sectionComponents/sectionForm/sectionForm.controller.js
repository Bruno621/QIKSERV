
export default class sectionFormController {
  static get UID() {
    return 'sectionFormController';
  }

  shouldShowParentSelection() {
    return this.FeatureService.hasNestedSections() &&
           !this.section.id &&
           !this.section.parentId;
  }

  constructor(FeatureService) {
    'ngInject';

    this.FeatureService = FeatureService;
  }
}
