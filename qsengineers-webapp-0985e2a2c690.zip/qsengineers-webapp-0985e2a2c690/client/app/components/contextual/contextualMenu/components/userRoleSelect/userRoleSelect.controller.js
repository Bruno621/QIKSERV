export default class userRoleSelectController {
  static get UID(){
    return "userRoleSelectController"
  }

  //simple selector
  onSelectRole(newRole, oldRole) {
    this.ngModel[0] = this.selectedRole;
  }

  //advanced selector
  toggleSelect(userRole) {
    if (!this.isSelected(userRole)){
        this.ngModel.push(userRole);
    } else {
        this.ngModel = this.ngModel.filter(activeRole => activeRole !== userRole);
    }

    this.checkIfAdminSelected();
  }

  checkIfAdminSelected() {
    let hasAdmin = false;
    this.ngModel.forEach(r => {
      if (r === 'ADMIN') {
        hasAdmin = true;
      }
    });
    this.adminChecked = hasAdmin;
  }

  isSelected(userRole){
    return this.adminChecked || this.ngModel.indexOf(userRole) != -1;
  }


  updateCurrentUser(){
    if (this.ngModel && this.ngModel.length == 1){
      var oldRole = this.ngModel[0];
      switch (oldRole) {
        case 'BRANCH_MANAGER':
          this.ngModel.length = 0
          this.ngModel.push('ANALYTICS_RESTRICTED');
          this.ngModel.push('MENU');
          this.ngModel.push('VENUE');
          break;
        case 'MANAGER':
          this.ngModel.length = 0
          this.ngModel.push('EVENT');
          this.ngModel.push('ANALYTICS');
          this.ngModel.push('LOYALTY');
          this.ngModel.push('OFFER');
          break;
      }
    }
  }

  getName(role){
    return this.UtilsService.getRoleAsString(role);
  }

 constructor(gettextCatalog, StateService, FeatureService, UserRole, UtilsService, $timeout) {
    "ngInject";
    let venue = StateService.venue;
    this.selectedRole = this.ngModel[0];
    this.UtilsService = UtilsService;

    this.listOfRoles = this.allRoles
                          .map(r => r.name ? r : null)
                          .filter( r => r !== null)
    if (venue) {
      this.listOfRoles = this.listOfRoles.filter( r=> r.id != 'OPERATOR');

      if(venue.isEvent()) {
        this.listOfRoles  = this.listOfRoles.filter( r => r.id != 'EVENT');
      }
    }

      this.roles = {
        ADMIN:{
          id: UserRole.ADMIN,
          name: UtilsService.getRoleAsString(UserRole.ADMIN),
          permissions:[
            gettextCatalog.getString("Order screen"),
            gettextCatalog.getString("Menus"),
            venue && venue.isEvent() ? gettextCatalog.getString("Events") : '',
            gettextCatalog.getString("Promotions"),
            FeatureService.hasBookingFeature() ? gettextCatalog.getString("Group Bookings") : '',
            FeatureService.hasVoucherFeature() ? gettextCatalog.getString("Gift Vouchers") : '',
            gettextCatalog.getString("Venue Settings"),
            gettextCatalog.getString("Analytics"),
            gettextCatalog.getString("Manage Users"),
            !StateService.isChannel ? gettextCatalog.getString("Employee Manager") : '',
            gettextCatalog.getString("Create new customers"),
            gettextCatalog.getString("Place orders")
          ]
        },
        MANAGER:{
          id: UserRole.MANAGER,
          name: UtilsService.getRoleAsString(UserRole.MANAGER),
          permissions:[
            gettextCatalog.getString("Order screen"),
            gettextCatalog.getString("Menus"),
            venue && venue.isEvent() ? gettextCatalog.getString("Events") : '',
            gettextCatalog.getString("Promotions"),
            FeatureService.hasBookingFeature() ? gettextCatalog.getString("Group Bookings") : '',
            FeatureService.hasVoucherFeature() ? gettextCatalog.getString("Gift Vouchers") : '',
          ]
        },
        STAFF:{
          id: UserRole.STAFF,
          name: UtilsService.getRoleAsString(UserRole.STAFF),
          permissions:[
            gettextCatalog.getString("Order screen"),
          ]
        }
      };

      if (StateService.isChannel) {
        this.roles['OPERATOR'] = {
          id: UserRole.OPERATOR,
          name: UtilsService.getRoleAsString(UserRole.OPERATOR),
          permissions: [
            gettextCatalog.getString("Create new customers"),
            gettextCatalog.getString("Place orders"),
          ]
        };
        this.roles['BRANCH_MANAGER'] = {
          id: UserRole.BRANCH_MANAGER,
          name: UtilsService.getRoleAsString(UserRole.BRANCH_MANAGER),
          permissions: [
            gettextCatalog.getString("Order screen"),
            gettextCatalog.getString("Menus"),
            gettextCatalog.getString("Analytics"),
          ]
        };
      }

    if (FeatureService.hasAdvancedRoles()){
      this.updateCurrentUser();
    }

    console.log("this", this.ngModel);

    this.checkIfAdminSelected();
  }
}
