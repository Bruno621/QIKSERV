
export default class sectionParentSelectionController {
  static get UID() {
    return 'sectionParentSelectionController';
  }

  constructor() {
    'ngInject';
  }
}
