// Controller
import VenueGroupBasicController from './venueGroupBasic.controller';

const VenueGroupBasicComponent = {
  bindings: {
    venueGroup: '<',
    params: '<?'
  },
  require: {
    contextualForm: '^^form',
  },
  controller: VenueGroupBasicController,
  controllerAs: '$venueGroupBasic',
  template: require('./venueGroupBasic.tpl.html')
};

export default VenueGroupBasicComponent;
