
export default class modifierMoreController {
  static get UID() {
    return 'modifierMoreController';
  }

  constructor() {
    'ngInject';
  }
}
