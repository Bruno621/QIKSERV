
// Import Style
import './customPrices.scss';

import angular from 'angular';

// Controller
import CustomPricesController from './customPrices.controller';

// Component
import CustomPricesComponent from './customPrices.component';

export default angular.module('customPrices', [])
  .controller(CustomPricesController.UID, CustomPricesController)
  .component('customPrices', CustomPricesComponent)
  .name;
