// Import Style
import './applicationSelect.scss';

// Import internal modules
import ApplicationSelectController from './applicationSelect.controller';
import ApplicationSelectComponent from './applicationSelect.component';

export default angular.module('applicationSelect', [])
  .controller(ApplicationSelectController.UID, ApplicationSelectController)
  .component('applicationSelect', ApplicationSelectComponent)
  .name;
