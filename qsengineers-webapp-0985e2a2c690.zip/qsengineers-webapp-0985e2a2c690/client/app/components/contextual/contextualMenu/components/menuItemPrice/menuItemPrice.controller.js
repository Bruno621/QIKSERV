
export default class menuItemPriceController {
  static get UID() {
    return 'menuItemPriceController';
  }

  constructor(gettextCatalog, FeatureService, StateService) {
    'ngInject';

    // Services
    this.gettextCatalog = gettextCatalog;

    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature() && !StateService.isChannel;
  }

  $onInit() {
    const {modifier} = this;

    if (!this.priceFieldName) {
      this.priceFieldName = 'entityPrice';
    }

    // SET default options for the modifier items
    this.setOptionsForModifierSizeItems();
    this.setOptionsForModifierPackItems();
  }

  $onChanges(changes) {
    console.log('MenuItemPriceController [$onChanges] - ', changes);
  }

  // variant = SIZE
  setOptionsForModifierSizeItems() {
    const {gettextCatalog} = this;

    this.modifierSizeItemsOptions = {
      hideOptionTooltip: gettextCatalog.getString('Hide option from size'),
      showOptionTooltip: gettextCatalog.getString('Show size option'),
      optionFieldLabel: gettextCatalog.getString('Name'),
      optionFieldDisplayLabel: gettextCatalog.getString('Display name'),
      addOptionLabel: gettextCatalog.getString('Add size'),
      minLength: 2,
      sortable: true,
    };

    if (this.ngMultiPriceProperty) {
      this.modifierSizeItemsOptions.priceProperty = this.ngMultiPriceProperty;
    }

    if (this.multiPriceFormName) {
      this.modifierSizeItemsOptions.formName = this.multiPriceFormName;
    }

    // make some features disabled for custom price
    // to allow the user edit only the price
    if (this.customPricesCtrl) {
      angular.extend(this.modifierSizeItemsOptions, {
        sortable: false,
        editable: false,
      });
    }
  }

  setOptionsForModifierPackItems() {
    const {gettextCatalog} = this;

    this.modifierPackItemsOptions = {
      hideOptionTooltip: gettextCatalog.getString('Hide option from pack'),
      showOptionTooltip: gettextCatalog.getString('Show pack option'),
      optionFieldLabel: gettextCatalog.getString('Name'),
      optionFieldDisplayLabel: gettextCatalog.getString('Display name'),
      addOptionLabel: gettextCatalog.getString('Add option'),
      minLength: 1,
      sortable: true,
    };
  }

  getPriceField() {
    return this.contextualForm[this.priceFieldName];
  }
}
