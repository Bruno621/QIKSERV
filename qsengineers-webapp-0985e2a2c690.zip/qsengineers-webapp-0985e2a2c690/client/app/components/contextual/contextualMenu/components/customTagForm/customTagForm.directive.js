import controller from './customTagForm.controller'

export default function customTagForm(){
  "ngInject";
  return {
    restrict: 'E',
    scope: {
      customTag: '=ngModel'
    },
    template: require("./customTagForm.tpl.html"),
    replace: true,
    controller: controller.UID,
    controllerAs: "customTagFormCtrl",
    bindToController: true,
    require: ['^form', '^contextualMenu', 'customTagForm'],
    link: (scope, el, attr, ctrls) => {

      ctrls[2].contextualForm = ctrls[0];
      ctrls[2].contextualMenuCtrl = ctrls[1];
    }
  }
}
