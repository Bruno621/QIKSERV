export default class inviteDetailsController {
  static get UID(){
    return "inviteDetailsController"
  }

  constructor() {
    "ngInject";

  }
}
