
// Import Style
import './modifierItemsPack.scss';

// Import internal modules
import ModifierItemsPackController from './modifierItemsPack.controller';
import ModifierItemsPackComponent from './modifierItemsPack.component';

export default angular.module('modifierItemsPack', [])
  .controller(ModifierItemsPackController.UID, ModifierItemsPackController)
  .component('modifierItemsPack', ModifierItemsPackComponent)
  .name;
