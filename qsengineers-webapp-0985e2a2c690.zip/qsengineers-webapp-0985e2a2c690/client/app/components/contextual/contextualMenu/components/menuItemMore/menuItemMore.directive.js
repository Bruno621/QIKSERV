import controller from './menuItemMore.controller'

export default function menuItemMore(){
  return {
    restrict: 'E',
    template: require("./menuItemMore.tpl.html"),
    controller: controller.UID,
    scope:{
      item: "=ngModel",
    },
    controllerAs: "menuItemMoreCtrl",
    bindToController: true,
    require:['^form', '^menuItemMore', '^contextualMenu'],
    link: (scope, el, attr, ctrls) => {
      ctrls[1].contextualForm = ctrls[0];
      ctrls[1].contextualMenuCtrl = ctrls[2];
    }
  }
}
