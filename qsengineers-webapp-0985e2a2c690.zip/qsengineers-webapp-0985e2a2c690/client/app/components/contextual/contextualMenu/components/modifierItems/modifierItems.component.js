
// Controller
import ModifierItemsController from './modifierItems.controller';

const ModifierItemsComponent = {
  bindings: {
    modifier: '<',
    options: '<?',
    onDelete: '&?',
    onVisibility: '&?',
    onAddOption: '&?',
    disabled: '=?',
  },
  controller: ModifierItemsController,
  controllerAs: '$modifierItems',
  template: require('./modifierItems.tpl.html'),
};

export default ModifierItemsComponent;
