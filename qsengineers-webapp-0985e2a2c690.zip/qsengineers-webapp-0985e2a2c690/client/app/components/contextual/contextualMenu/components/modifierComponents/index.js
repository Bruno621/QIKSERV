
// Import internal modules
import modifierBasic from './modifierBasic';
import modifierMore from './modifierMore';

export default angular.module('modifierComponents', [
  modifierBasic,
  modifierMore,
])
  .name;
