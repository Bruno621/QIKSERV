export default class tagActionBasicController {
  static get UID(){
    return 'tagActionBasicController';
  }

  /* @ngInject */
  constructor($timeout, StateService) {
    'ngInject';

    this.tagGroups = [];
    this.shouldShowOperatorsCheckbox = StateService.isChannel;

    this.appTypes = [
      {name: 'Any application', value: null},
      {name: 'Web only', value: 'WEB'},
      {name: 'Mobile only', value: 'MOBILE'},
    ];

    if(this.tagAction) {
      const currentName = this.tagAction.applicationType ? this.tagAction.applicationType : null;
      this.appTypes.forEach(a => {
        if(a.value === currentName) {
          a.selected = true;
        }
      });
    } else {
      // else selected ALL as default
      this.appTypes[0].selected = true;
    }

    $timeout(() => {
      this.tagGroups = this.contextualMenuCtrl.params.tagGroups;
    });
  }
}
