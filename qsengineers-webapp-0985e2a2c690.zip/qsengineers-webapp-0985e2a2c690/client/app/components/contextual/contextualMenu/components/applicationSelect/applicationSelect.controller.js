
export default class applicationSelectController {
  static get UID() {
    return 'applicationSelectController';
  }

  onToggle(application) {
    const {selected} = this;
    const index = selected.indexOf(application.id);

    if (index === -1) {
      selected.push(application.id);
    } else {
      selected.splice(index, 1);
    }
  }

  isApplicationSelected(application) {
    return this.selected.indexOf(application.id) > -1;
  }

  /* @ngInject */
  constructor() {
    'ngInject';

    // Defaults
    this.selected = this.selected || [];
  }
}
