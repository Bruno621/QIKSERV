export default class promotionTabsController {
  static get UID(){
    return "promotionTabsController"
  }

  constructor() {
    "ngInject";

  }
}