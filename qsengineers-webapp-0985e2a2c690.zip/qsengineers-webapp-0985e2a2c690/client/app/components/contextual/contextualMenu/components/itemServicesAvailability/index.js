
// Import Style
import './itemServicesAvailability.scss';

import angular from 'angular';

// Import internal modules
import ItemServiceAvailabilityController from './itemServicesAvailability.controller';
import ItemServiceAvailabilityComponent from './itemServicesAvailability.component';

export default angular.module('itemServicesAvailability', [])
  .controller(ItemServiceAvailabilityController.UID, ItemServiceAvailabilityController)
  .component('itemServicesAvailability', ItemServiceAvailabilityComponent)
  .name;
