
// Import Style
import './modifierMore.scss';

// Import internal modules
import ModifierMoreController from './modifierMore.controller';
import ModifierMoreComponent from './modifierMore.component';

export default angular.module('modifierMore', [])
  .controller(ModifierMoreController.UID, ModifierMoreController)
  .component('modifierMore', ModifierMoreComponent)
  .name;
