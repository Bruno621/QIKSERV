
export default function promotionTarget(OfferService, PromotionTarget) {
  'ngInject';

  return {
    restrict: 'E',
    scope: {
      promotion:"=",
    },
    template: require("./promotionTarget.tpl.html"),
    link: (scope, el, attr, ctrl) => {

      scope.onTargetChange = onTargetChange;
      scope.onChangeQualifiedItemsTarget = onChangeQualifiedItemsTarget;
      scope.onChangeApplyToQualifedItems = onChangeApplyToQualifedItems;

      scope.promotion.targetElements = OfferService.getTargetElements(scope.promotion);
      scope.promotion.qualifiedItemsTargetElements = OfferService.getQualifiedItemsTargetElements(scope.promotion);

      function onTargetChange() {
        if (scope.promotion.target === PromotionTarget.BASKET) {
          scope.promotion.applyOnce = 0;
        } else {
          scope.promotion.applyToQualifiedItems = 0;
          scope.promotion.qualifiedItemsTarget = null;
        }

        scope.promotion.targetElements = [];
        scope.promotion.qualifiedItemsTargetElements = [];
      }

      function onChangeQualifiedItemsTarget() {
        scope.promotion.qualifiedItemsTargetElements = [];
      }

      function onChangeApplyToQualifedItems() {
        if (!scope.promotion.qualifiedItemsTarget) {
          scope.promotion.qualifiedItemsTarget = PromotionTarget.ITEM;
        } else {
          scope.promotion.qualifiedItemsTarget = null;
          scope.promotion.qualifiedItemsTargetElements = [];
        }
      }
    }
  }
}
