
// Controller
import ItemServiceAvailabilityController from './itemServicesAvailability.controller';

const ItemServiceAvailabilityComponent = {
  bindings: {
    item: '=',
  },
  controller: ItemServiceAvailabilityController,
  controllerAs: '$itemService',
  template: require('./itemServicesAvailability.tpl.html'),
};

export default ItemServiceAvailabilityComponent;
