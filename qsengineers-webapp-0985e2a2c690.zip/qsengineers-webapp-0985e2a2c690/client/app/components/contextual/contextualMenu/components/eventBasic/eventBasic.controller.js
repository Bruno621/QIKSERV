export default class eventBasicController {
  static get UID(){
    return "eventBasicController"
  }

  shouldShowInputDays() {
    return this.openType === this.EventPreorderOpenType.CUSTOM;
  }

  onTypeChange() {
      switch(this.openType) {
        case this.EventPreorderOpenType.TODAY:
          this.event.preorderOpenDays = null;
          break;
        case this.EventPreorderOpenType.ONEWEEK:
          this.event.preorderOpenDays = 7;
          break;
        case this.EventPreorderOpenType.TWOWEEKS:
          this.event.preorderOpenDays = 14;
          break;
        case this.EventPreorderOpenType.CUSTOM:
          this.event.preorderOpenDays = 0;
          break;
      }
  }

  /* @ngInject */
  constructor($scope, EventPreorderOpenType) {
    'ngInject';

    this.EventPreorderOpenType = EventPreorderOpenType;

    if(!this.event.preorderOpenDays) {
      this.openType =  EventPreorderOpenType.TODAY;
    } else if(this.event.preorderOpenDays === 7) {
      this.openType = EventPreorderOpenType.ONEWEEK;
    } else if(this.event.preorderOpenDays === 14) {
      this.openType = EventPreorderOpenType.TWOWEEKS;
    } else {
      this.openType = EventPreorderOpenType.CUSTOM;
    }
  }
}
