
import controller from './sectionHours.controller';

export default function sectionHours() {
  return {
    restrict: 'E',
    scope: {
      section: '=',
    },
    replace: true,
    template: require('./sectionHours.tpl.html'),
    controller: controller.UID,
    controllerAs: '$sectionHours',
    bindToController: true,
    require: ['^form'],
    link: (scope, el, attr, ctrls) => {
    },
  };
}
