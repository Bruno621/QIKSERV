export default class menuItemSizeController {
  static get UID() {
    return 'menuItemSizeController';
  }

  createModifier() {
    const {
      StateService, modifier,
      MODIFIER_TYPE, CHOOSE_A_SIZE_TRANSLATION, CHOOSE_AN_OPTION_TRANSLATION
    } = this;

    // Default modifier data (MODI)
    const defaults = {
      variant: MODIFIER_TYPE.MODI,
      venueId: StateService.venue && StateService.venue.id,
      channelId: StateService.channel && StateService.channel.id,
      items: [],
    };

    if (!angular.isObject(modifier)) {
      return new Preoday.Modifier(defaults);
    }

    // Custom modifier data (e.g SIZE, PACK)
    angular.extend(defaults, {
      maxChoices: 1,
      minChoices: 1,
      position: 0,
      $deletedItems: []
    });

    if (modifier.variant === MODIFIER_TYPE.SIZE) {
      angular.extend(defaults, {
        variant: MODIFIER_TYPE.SIZE,
        name: CHOOSE_A_SIZE_TRANSLATION,
        internalName: CHOOSE_A_SIZE_TRANSLATION
      });

    } else if (modifier.variant === MODIFIER_TYPE.PACK) {
      angular.extend(defaults, {
        variant: MODIFIER_TYPE.PACK,
        name: CHOOSE_AN_OPTION_TRANSLATION,
        internalName: CHOOSE_AN_OPTION_TRANSLATION
      });
    }

    return new Preoday.Modifier(defaults);
  }

  onVisibility(modifierItem, isVisible) {
    const {
      DialogService, LabelService, ErrorService,
      modifier,
    } = this;
    const visibleItems = modifier.items.filter(o => o.visible === 1);

    // we only allow change visibility if there are 2 or more items visible.
    // User cant hide all sizes from an item.
    if (isVisible === 0 && visibleItems.length < 2) {
      const { title, message } = ErrorService.ITEMS_HIDE_SIZE;

      DialogService.show(title, message, [{
        name: LabelService.CONFIRMATION,
      }]);
    } else {
      modifierItem.visible = isVisible;
    }
  }

  onSizeSelect() {
    const {modifier, modifierType, modifierTypeMap} = this;

    // UPDATE the current modifier type (variant)
    this.modifierType = modifier.variant;

    if (modifier.isModifier()) {
      return;
    }

    // CREATE a new `modifier` data based on the previous `variant` selection
    const modifierToCache = angular.extend({}, modifier, {
      variant: modifierType
    });

    // CACHE the previous `modifier` data
    this.modifierTypeMap[modifierType] = new Preoday.Modifier(modifierToCache);

    // GET the cached modifier
    let cachedModifier = this.modifierTypeMap[this.modifierType];

    if (!cachedModifier) {
      cachedModifier = this.createModifier();
    }

    // UPDATE the current `modifier` data with the cached one
    this.modifier = cachedModifier;
  }

  /* @ngInject */
  constructor(StateService, UserService, FeatureService,
    DialogService, LabelService, ErrorService, UtilsService, gettextCatalog) {
    'ngInject';

    // Services
    this.StateService = StateService;
    this.DialogService = DialogService;
    this.LabelService = LabelService;
    this.ErrorService = ErrorService;

    // Defaults
    const locale = (StateService.channel && StateService.channel.locale)
        || (StateService.venue && StateService.venue.locale)
        || (UserService.isLogged() && UserService.getCurrent().locale)
        || (UtilsService.DEFAULT_LOCALE);

    const language = UtilsService.getLanguage(locale);

    // Constants
    const MODIFIER_TYPE = Preoday.constants.ModifierType;
    const CHOOSE_A_SIZE_TRANSLATION = UtilsService.getStringFormFor(language, 'Choose a size');
    const CHOOSE_AN_OPTION_TRANSLATION = UtilsService.getStringFormFor(language, 'Choose an option');

    this.CHOOSE_A_SIZE_TRANSLATION = CHOOSE_A_SIZE_TRANSLATION;
    this.CHOOSE_AN_OPTION_TRANSLATION = CHOOSE_AN_OPTION_TRANSLATION;
    this.MODIFIER_TYPE = MODIFIER_TYPE;

    this.hasPromotionPackFeature = FeatureService.hasPromotionPackFeature();
    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature() && !StateService.channel;
    this.hasCaloriesInformationFlag = FeatureService.hasCaloriesInformationFlag();
    this.modifierTypeMap = {};

    if (this.modifier && this.modifier.id) {
      this.modifier.$deletedItems = [];
      this.modifierTypeMap[this.modifier.variant] = this.modifier;
    } else {
      this.modifier = this.createModifier();
    }

    if (this.modifier.isSize() && this.item.isVoucher()) {
      this.modifier.variant = MODIFIER_TYPE.MODI;
    }

    this.modifierType = this.modifier.variant;
  }
}
