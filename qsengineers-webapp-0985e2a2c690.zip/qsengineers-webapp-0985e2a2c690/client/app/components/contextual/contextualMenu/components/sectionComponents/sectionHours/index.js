
// Import Style
import './sectionHours.scss';

// Import internal modules
import controller from './sectionHours.controller';
import directive from './sectionHours.directive';

import SectionHour from './sectionHour';

export default angular.module('sectionHours', [
  SectionHour,
])
  .controller(controller.UID, controller)
  .directive('sectionHours', directive)
  .name;
