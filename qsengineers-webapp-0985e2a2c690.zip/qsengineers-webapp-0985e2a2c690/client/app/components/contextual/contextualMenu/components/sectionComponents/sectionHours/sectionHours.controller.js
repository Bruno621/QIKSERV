
export default class sectionHoursController {
  static get UID() {
    return 'sectionHoursController';
  }

  findHourByDay(hours, preodayWeekday) {
    return hours.find((hour) => {
      return hour.day === preodayWeekday;
    });
  }

  buildDaysHours() {
    const hours = angular.copy(this.section.hours);

    this.section.$sectionHours = [];

    const startOfWeek = moment().startOf('isoweek');

    for (let i = 0; i < 7; i++) {
      const preodayWeekday = (i === 6 ? 1 : i + 2);
      const hour = this.findHourByDay(hours, preodayWeekday);
      const sectionHour = angular.extend(hour || {}, {
        $label: startOfWeek.format('ddd'),
        day: preodayWeekday,
      });

      this.section.$sectionHours.push(sectionHour);

      startOfWeek.add(1, 'days');
    }
  }

  constructor() {
    'ngInject';

    this.buildDaysHours();
  }
}
