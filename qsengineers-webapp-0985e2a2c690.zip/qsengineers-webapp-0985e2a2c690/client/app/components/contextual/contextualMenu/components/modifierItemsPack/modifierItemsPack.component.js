
// Controller
import ModifierItemsPackController from './modifierItemsPack.controller';

const ModifierItemsPackComponent = {
  bindings: {
    modifier: '<',
    options: '<?',
    onDelete: '&?',
    onAddOption: '&?',
    disabled: '=?',
  },
  controller: ModifierItemsPackController,
  controllerAs: '$modifierItemsPack',
  template: require('./modifierItemsPack.tpl.html'),
};

export default ModifierItemsPackComponent;
