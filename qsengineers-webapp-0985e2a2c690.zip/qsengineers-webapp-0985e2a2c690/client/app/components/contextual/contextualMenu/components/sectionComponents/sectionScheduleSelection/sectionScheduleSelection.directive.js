
import controller from './sectionScheduleSelection.controller';

export default function sectionScheduleSelection() {
  return {
    restrict: 'E',
    scope: {
      section: '=',
    },
    replace: true,
    template: require('./sectionScheduleSelection.tpl.html'),
    controller: controller.UID,
    controllerAs: '$sectionSchedule',
    bindToController: true,
    require: ['^form'],
    link: (scope, el, attr, ctrls) => {
    },
  };
}
