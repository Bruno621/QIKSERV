
// Import Style
import './sectionScheduleSelection.scss';

// Import internal modules
import controller from './sectionScheduleSelection.controller';
import directive from './sectionScheduleSelection.directive';

export default angular.module('sectionScheduleSelection', [])
  .controller(controller.UID, controller)
  .directive('sectionScheduleSelection', directive)
  .name;
