// Import Style
import './menuItemMore.scss';

// Import internal modules
import controller from './menuItemMore.controller';
import directive from './menuItemMore.directive';

import CustomPrices from '../customPrices';
import ItemServicesAvailability from '../itemServicesAvailability';

export default angular.module('menuItemMore', [CustomPrices, ItemServicesAvailability])

  .controller(controller.UID, controller)
  .directive('menuItemMore', directive)
  .name;
