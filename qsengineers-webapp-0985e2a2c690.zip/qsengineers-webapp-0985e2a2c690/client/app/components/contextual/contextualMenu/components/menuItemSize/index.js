
// Import Style
import './menuItemSize.scss';

import angular from 'angular';

// Import internal modules
import MenuItemSizeController from './menuItemSize.controller';
import MenuItemSizeDirective from './menuItemSize.directive';

import MenuItemPriceComponent from '../menuItemPrice';

export default angular.module('menuItemSize', [MenuItemPriceComponent])
  .controller(MenuItemSizeController.UID, MenuItemSizeController)
  .directive('menuItemSize', MenuItemSizeDirective)
  .name;
