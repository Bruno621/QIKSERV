
// Controller
import MenuItemPriceController from './menuItemPrice.controller';

const MenuItemPriceComponent = {
  bindings: {
    item: '=',
    ngSinglePriceModel: '=',
    ngMultiPriceModel: '=',
    ngMultiPriceProperty: '@?', // used to set the modifier item price
    priceFieldName: '@?', // used to set the entity price field name

    // used to set the modifier items form name
    // and allow validate it in the ItemService.hasMoreTabErrors
    multiPriceFormName: '@?',
    isMultiPrice: '=?',
    isPackPrice: '=?',
    onVisibility: '&?',
    disabled: '=?',
  },
  require: {
    contextualForm: '^^form',
    customPricesCtrl: '?^^customPrices',
  },
  controller: MenuItemPriceController,
  controllerAs: '$menuItemPrice',
  template: require('./menuItemPrice.tpl.html'),
};

export default MenuItemPriceComponent;
