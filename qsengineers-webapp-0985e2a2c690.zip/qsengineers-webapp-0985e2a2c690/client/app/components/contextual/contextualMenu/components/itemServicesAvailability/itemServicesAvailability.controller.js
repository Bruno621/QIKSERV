
export default class itemServicesAvailabilityController {
  static get UID() {
    return 'itemServicesAvailabilityController';
  }

  constructor() {
    'ngInject';
  }
}
