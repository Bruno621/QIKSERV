
export default class venueGroupAdvancedController {
  static get UID() {
    return 'venueGroupAdvancedController';
  }
}
