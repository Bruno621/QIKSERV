export default function promotionDisplay() {
  return {
    restrict: 'E',
    require: '^contextualMenu',
    replace: true,
    scope: {
      promotion: '=',
    },
    template: require('./promotionDisplay.tpl.html'),
    link: postLink
  };

  function postLink(scope, el, attr, ctrl) {
    scope.contextualMenuCtrl = ctrl;

    scope.onDisplayChange = () => {
      if (!scope.promotion.visible && !scope.promotion.dialogFlag) {
        scope.promotion.displayName = '';
      }
    };
  }
}
