
import controller from './sectionParentSelection.controller';

export default function sectionParentSelection() {
  return {
    restrict: 'E',
    scope: {
      section: '=',
    },
    replace: true,
    template: require('./sectionParentSelection.tpl.html'),
    controller: controller.UID,
    controllerAs: '$sectionParent',
    bindToController: true,
    require: ['^form'],
    link: (scope, el, attr, ctrls) => {
    },
  };
}
