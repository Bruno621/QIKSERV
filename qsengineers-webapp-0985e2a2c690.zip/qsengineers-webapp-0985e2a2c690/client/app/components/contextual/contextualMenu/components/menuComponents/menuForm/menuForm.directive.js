import controller from './menuForm.controller'

export default function menuForm(){
  return {
    restrict: 'E',
    scope: {
      menu: '='
    },
    template: require("./menuForm.tpl.html"),
    controller: controller.UID,
    controllerAs: "$menu",
    bindToController: true,
    require: ['^form', 'menuForm', '^contextualMenu'],
    link: (scope, el, attr, ctrls) => {
      ctrls[1].contextualMenuCtrl = ctrls[2];
      ctrls[1].contextualForm = ctrls[0];
    }
  }
}
