
import controller from './sectionForm.controller';

export default function sectionForm() {
  return {
    restrict: 'E',
    scope: {
      section: '=',
      tags: '=',
    },
    template: require('./sectionForm.tpl.html'),
    controller: controller.UID,
    controllerAs: '$section',
    bindToController: true,
    require: ['^form', 'sectionForm'],
    link: (scope, el, attr, ctrls) => {
      ctrls[1].contextualForm = ctrls[0];
    },
  };
}
