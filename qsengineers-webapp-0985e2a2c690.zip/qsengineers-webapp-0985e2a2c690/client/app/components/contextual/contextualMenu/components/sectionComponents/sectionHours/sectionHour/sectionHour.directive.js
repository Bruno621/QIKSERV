
import controller from './sectionHour.controller';

export default function sectionHour() {
  return {
    restrict: 'E',
    scope: {
      hour: '=',
      index: '=',
    },
    replace: true,
    template: require('./sectionHour.tpl.html'),
    controller: controller.UID,
    controllerAs: '$sectionHour',
    bindToController: true,
    require: ['^form', 'sectionHour'],
    link: (scope, el, attr, ctrls) => {
      ctrls[1].contextualForm = ctrls[0];
    },
  };
}
