
export default class sectionHourController {
  static get UID() {
    return 'sectionHourController';
  }

  constructor() {
    'ngInject';

    if (this.hour.open) {
      const openTime = this.hour.open.slice(0, 5).split(':');
      const closeTime = this.hour.close.slice(0, 5).split(':');

      this.hour.$open = moment().hours(openTime[0]).minutes(openTime[1]);
      this.hour.$close = moment().hours(closeTime[0]).minutes(closeTime[1]);
    }
  }
}
