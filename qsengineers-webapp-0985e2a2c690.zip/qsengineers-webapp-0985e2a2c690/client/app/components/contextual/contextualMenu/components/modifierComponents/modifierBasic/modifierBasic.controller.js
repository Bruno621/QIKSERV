
export default class modifierBasicController {
  static get UID() {
    return 'modifierBasicController';
  }

  constructor(FeatureService, StateService, PermissionService, Permissions) {
    'ngInject';

    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature();
    this.hasMenuItemExternalIdFeature = FeatureService.hasMenuItemExternalIdFeature();

    this.disableInternalName = FeatureService.hasExternalMenusFeature() && !StateService.isChannel;

    this.hasMenuCreatePermission = PermissionService.hasPermission(Permissions.MENU_CREATE);
  }

  $onInit() {

  }
}
