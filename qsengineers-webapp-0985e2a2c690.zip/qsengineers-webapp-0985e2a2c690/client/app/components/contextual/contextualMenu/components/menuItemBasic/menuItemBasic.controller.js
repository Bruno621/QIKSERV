export default class menuItemBasicController {
  static get UID(){
    return "menuItemBasicController"
  }

  shouldShowSpecialInstructions() {
    const { isChannel, specialInstructionsSettings } = this;

    return specialInstructionsSettings && !isChannel;
  }

  getSpecialInstructionTagText() {
    const { item, gettextCatalog } = this;

    if (item.notesFlag) {
      return gettextCatalog.getString('ENABLED');
    }

    return gettextCatalog.getString('DISABLED');
  }

  /* @ngInject */
  constructor($scope, BroadcastEvents, ItemService, $timeout, FeatureService, StateService, PermissionService,
    Permissions, gettextCatalog) {
    'ngInject';

    this.gettextCatalog = gettextCatalog;

    this.tags = [];

    this.hasManualSkuFeature = FeatureService.hasManualSkuFeature();

    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature() && !StateService.isChannel;
    this.hasMenuItemSpecialInstructionsFeature = FeatureService.hasMenuItemSpecialInstructionsFeature();
    
    this.hasMenuCreatePermission = PermissionService.hasPermission(Permissions.MENU_CREATE);

    this.isChannel = StateService.isChannel;
    this.venue = StateService.venue;
    this.specialInstructionsSettings = this.venue ? this.venue.specialInstructionsSettings : null;

    $timeout(() => {
      this.tags = this.contextualMenuCtrl.params.tags;
    });

    $scope.$on(BroadcastEvents.ON_CONTEXTUAL_FORM_SUBMITTED, () => {
      if (this.contextualForm.selectedTabIndex === 1) {

        if (ItemService.hasBasicTabErrors(this.contextualForm, this.item)) {
          this.contextualForm.selectedTabIndex = 0;
        } else if (this.item.isVoucher() && ItemService.hasAdvancedTabErrors(this.contextualForm, this.item)) {
          this.contextualForm.selectedTabIndex = 2;
        }

        return;
      }

      if (this.contextualForm.selectedTabIndex === 0 && !ItemService.hasBasicTabErrors(this.contextualForm, this.item)) {
        if (this.item.isVoucher() && ItemService.hasAdvancedTabErrors(this.contextualForm, this.item)) {
          this.contextualForm.selectedTabIndex = 2;
        }

        return;
      }

      if (this.contextualForm.selectedTabIndex === 2 && !ItemService.hasAdvancedTabErrors(this.contextualForm, this.item)) {

        if (ItemService.hasBasicTabErrors(this.contextualForm, this.item)) {
          this.contextualForm.selectedTabIndex = 0;
        }

        return;
      }
    });
  }
}
