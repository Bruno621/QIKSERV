
// Import Style
import './sectionForm.scss';

// Import internal modules
import controller from './sectionForm.controller';
import directive from './sectionForm.directive';

import tagSelect from '../../tagSelect';
import sectionParentSelection from '../sectionParentSelection';

export default angular.module('sectionForm', [
  tagSelect,
  sectionParentSelection,
])
  .controller(controller.UID, controller)
  .directive('sectionForm', directive)
  .name;
