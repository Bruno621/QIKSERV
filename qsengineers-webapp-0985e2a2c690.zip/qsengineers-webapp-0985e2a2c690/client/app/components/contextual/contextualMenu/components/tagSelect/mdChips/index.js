import directive from './mdChips.directive';

export default directive;