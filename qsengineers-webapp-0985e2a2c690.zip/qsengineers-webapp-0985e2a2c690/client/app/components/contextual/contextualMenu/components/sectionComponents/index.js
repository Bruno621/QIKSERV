
// Import internal modules
import sectionForm from './sectionForm';
import sectionScheduleSelection from './sectionScheduleSelection';
import sectionHours from './sectionHours';

export default angular.module('sectionComponents', [
  sectionForm,
  sectionScheduleSelection,
  sectionHours,
])
  .name;
