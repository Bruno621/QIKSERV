
// Import Style
import './modifierItems.scss';

import angular from 'angular';

// Import internal modules
import ModifierItemsController from './modifierItems.controller';
import ModifierItemsComponent from './modifierItems.component';

export default angular.module('modifierItems', [])
  .controller(ModifierItemsController.UID, ModifierItemsController)
  .component('modifierItems', ModifierItemsComponent)
  .name;
