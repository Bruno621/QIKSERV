
export default class awardFormController {
  static get UID() {
    return 'awardFormController';
  }

  constructor() {
    'ngInject';
  }
}
