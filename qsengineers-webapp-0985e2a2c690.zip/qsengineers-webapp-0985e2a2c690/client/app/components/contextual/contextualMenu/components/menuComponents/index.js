// Import internal modules
import menuForm from './menuForm';

export default angular.module('menuComponents', [
  menuForm
])
  .name;
