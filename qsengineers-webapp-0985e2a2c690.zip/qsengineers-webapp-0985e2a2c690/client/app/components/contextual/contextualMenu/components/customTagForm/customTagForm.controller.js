
export default class customTagFormController {
  static get UID(){
    return "customTagFormController"
  }

  constructor() {
    "ngInject";

  }
}
