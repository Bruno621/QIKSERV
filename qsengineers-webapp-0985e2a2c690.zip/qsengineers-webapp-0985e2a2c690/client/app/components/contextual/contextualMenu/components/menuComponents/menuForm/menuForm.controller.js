export default class menuFormController {
  static get UID(){
    return "menuFormController"
  }

  constructor() {
    "ngInject";

  }
}
