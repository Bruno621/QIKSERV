// Import Style
import './venueGroupAdvanced.scss';

// Import internal modules
import VenueGroupAdvancedController from './venueGroupAdvanced.controller';
import VenueGroupAdvancedComponent from './venueGroupAdvanced.component';

export default angular.module('venueGroupAdvanced', [])
  .controller(VenueGroupAdvancedController.UID, VenueGroupAdvancedController)
  .component('venueGroupAdvanced', VenueGroupAdvancedComponent)
  .name;
