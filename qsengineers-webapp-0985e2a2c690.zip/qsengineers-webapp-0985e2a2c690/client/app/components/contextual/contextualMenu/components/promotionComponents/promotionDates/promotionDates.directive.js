export default function promotionDates(){
  return {
    restrict: 'E',
    require: '^contextualMenu',
    replace: true,
    scope: {
      promotion: '=',
    },
    template: require('./promotionDates.tpl.html'),
    link: (scope, el, attr, contextualMenuCtrl) => {
      scope.contextualMenuCtrl = contextualMenuCtrl;
      scope.contextualForm = contextualMenuCtrl.contextualForm;

      if (scope.promotion.startDate){
        scope.$startDate = moment(scope.promotion.startDate).toDate();
        scope.$startTime = moment(scope.promotion.startDate).toDate();
      }

      if (scope.promotion.endDate){
        scope.$endDate = moment(scope.promotion.endDate).toDate()
        scope.$endTime = moment(scope.promotion.endDate).toDate()
      }

      function setStartDate(date, time) {
        date = date || new Date();
        time = time || new Date();
        scope.promotion.startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(),
               time.getHours(), time.getMinutes(), time.getSeconds());
      }

      scope.selectStartDate = () => {
        if (scope.$startDate) {
          setStartDate(scope.$startDate, scope.$startTime)
        }
      };

      scope.selectStartTime = () => {
        if (scope.$startTime) {
          setStartDate(scope.$startDate, scope.$startTime)
        }
      };

      function setEndDate(date, time) {
        date = date || new Date();
        time = time || new Date();
        scope.promotion.endDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(),
               time.getHours(), time.getMinutes(), time.getSeconds());
      }

      scope.selectEndDate = () => {
        if (scope.$endDate) {
          setEndDate(scope.$endDate, scope.$endTime)
        }
      };

      scope.selectEndTime = () => {
        if (scope.$endTime) {
          setEndDate(scope.$endDate, scope.$endTime)
        }
      };
    }
  }
}
