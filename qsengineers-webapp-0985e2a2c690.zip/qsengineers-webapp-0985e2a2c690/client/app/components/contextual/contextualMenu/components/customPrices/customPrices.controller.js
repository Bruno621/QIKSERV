
export default class CustomPricesController {
  static get UID() {
    return 'CustomPricesController';
  }

  constructor(UtilsService, FeatureService, StateService, gettextCatalog) {
    'ngInject';

    // Services
    this.UtilsService = UtilsService;
    this.StateService = StateService;
    this.gettextCatalog = gettextCatalog;
    // Defaults
    this.hasExternalMenusFeature = FeatureService.hasExternalMenusFeature() && !StateService.isChannel;
  }

  $onInit() {
    

    //this is all terrible and should be replaced with it's own table/models in the database.
    
    this.overridesMap = [
      {
        itemProperty: 'deliveryPriceOverride',
        label: this.gettextCatalog.getString('Override price for delivery'),
        description: this.gettextCatalog.getString('This price will be applied to all delivery orders.'),
      }, 
      {
        itemProperty: 'seatPriceOverride',
        label: this.gettextCatalog.getString('Override price for seat/to table'),
        description: this.gettextCatalog.getString('This price will be applied to all seat/table orders.'),
      }];
     this.StateService.venue.deliveryServices?.forEach(ds=>{
      switch (ds.type) {
        case 'DELIVEROO':
          this.overridesMap.push({
            itemProperty: 'deliverooPriceOverride', 
            label: this.gettextCatalog.getString('Override price for Deliveroo'),
            description: this.gettextCatalog.getString('This price will be applied to all Deliveroo orders.'),
          })          
          break;
        case 'DELIVERY_HERO':
          this.overridesMap.push({
              itemProperty: 'deliveryHeroPriceOverride',
              label: this.gettextCatalog.getString('Override price for Delivery Hero'),
              description: this.gettextCatalog.getString('This price will be applied to all Delivery Hero orders.'),
            });
          break;
        case 'GLOVO':
          this.overridesMap.push({
              itemProperty: 'glovoPriceOverride',
              label: this.gettextCatalog.getString('Override price for Glovo'),
              description: this.gettextCatalog.getString('This price will be applied to all Glovo orders.'),
            });
          break;
        case 'JUST_EAT':
          this.overridesMap.push(  {
              itemProperty: 'justEatPriceOverride',
              label: this.gettextCatalog.getString('Override price for Just Eat'),
              description: this.gettextCatalog.getString('This price will be applied to all Just Eat orders.'),
            });
          break;
        case 'UBER':
          this.overridesMap.push({
              itemProperty: 'uberPriceOverride',
              label: this.gettextCatalog.getString('Override price for Uber Eats'),
              description: this.gettextCatalog.getString('This price will be applied to all Uber Eats orders.'),
            });
            break;            
        default:
          break;
      }

     });
    
  

    // Make the checkbox selected if needed
    if (this.isMultiPrice()) {
      this.checkOverrideIsSet(this.modifier.items[0]);
    } else {
      this.checkOverrideIsSet(this.item);
    }
  }

  isMultiPrice() {
    const { item, modifier } = this;

    return (modifier && modifier.isSize()) || !item;
  }

  checkOverrideIsSet(item) {
    const { UtilsService } = this;

    this.overridesMap.forEach(prop =>{
      prop.$shouldOverride = UtilsService.isNumber(item[prop.itemProperty]);
    })
  }

  onPriceChange(overrideMapitem){
    if (!overrideMapitem.$shouldOverride) {
      this.resetItemPrices(overrideMapitem.itemProperty);
    }
  }

  resetItemPrices(priceProperty) {
    const { item, modifier } = this;

    if (this.isMultiPrice()) {
      // RESET modifier items prices
      modifier.items.forEach((it) => {
        it[priceProperty] = null;
      });
    } else {
      // RESET item price
      item[priceProperty] = null;
    }
  }
}
