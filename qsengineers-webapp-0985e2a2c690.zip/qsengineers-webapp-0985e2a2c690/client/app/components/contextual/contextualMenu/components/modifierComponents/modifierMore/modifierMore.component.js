
// Controller
import ModifierMoreController from './modifierMore.controller';

const ModifierMoreComponent = {
  bindings: {
    modifier: '<',
  },
  controller: ModifierMoreController,
  controllerAs: '$modifierMore',
  template: require('./modifierMore.tpl.html'),
};

export default ModifierMoreComponent;
