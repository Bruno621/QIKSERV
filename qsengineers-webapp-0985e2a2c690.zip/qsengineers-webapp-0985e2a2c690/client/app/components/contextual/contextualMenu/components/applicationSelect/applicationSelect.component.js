// Controller
import ApplicationSelectController from './applicationSelect.controller';

const ApplicationSelectComponent = {
  bindings: {
    applications: '<',
    selected: '<?'
  },
  controller: ApplicationSelectController,
  controllerAs: '$applicationSelect',
  template: require('./applicationSelect.tpl.html')
};

export default ApplicationSelectComponent;
