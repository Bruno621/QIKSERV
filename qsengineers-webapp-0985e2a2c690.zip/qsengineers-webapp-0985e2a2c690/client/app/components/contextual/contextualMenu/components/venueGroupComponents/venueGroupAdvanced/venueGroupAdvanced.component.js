// Controller
import VenueGroupAdvancedController from './venueGroupAdvanced.controller';

const VenueGroupAdvancedComponent = {
  bindings: {
    venueGroup: '<',
    params: '<?'
  },
  require: {
    contextualForm: '^^form',
  },
  controller: VenueGroupAdvancedController,
  controllerAs: '$venueGroupAdvanced',
  template: require('./venueGroupAdvanced.tpl.html')
};

export default VenueGroupAdvancedComponent;
