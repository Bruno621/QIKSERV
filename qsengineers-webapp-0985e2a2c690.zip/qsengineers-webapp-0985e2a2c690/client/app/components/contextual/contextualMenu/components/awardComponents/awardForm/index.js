
// Import Style
import './awardForm.scss';

// Import internal modules
import controller from './awardForm.controller';
import directive from './awardForm.directive';

export default angular.module('awardForm', [])
  .controller(controller.UID, controller)
  .directive('awardForm', directive)
  .name;
