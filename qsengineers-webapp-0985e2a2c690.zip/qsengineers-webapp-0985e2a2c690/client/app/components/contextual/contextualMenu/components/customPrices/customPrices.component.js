
// Controller
import CustomPricesController from './customPrices.controller';

const CustomPricesComponent = {
  bindings: {
    item: '<?',
    modifier: '<'
  },
  controller: CustomPricesController,
  controllerAs: '$prices',
  template: require('./customPrices.tpl.html'),
};

export default CustomPricesComponent;
