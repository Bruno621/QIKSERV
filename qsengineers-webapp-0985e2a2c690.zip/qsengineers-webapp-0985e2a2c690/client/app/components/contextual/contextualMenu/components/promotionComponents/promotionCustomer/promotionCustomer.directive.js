export default function promotionCustomer(){
  return {
    restrict: 'E',
    scope: {
      promotion:"=",
    },
    template: require("./promotionCustomer.tpl.html"),
    replace:true,
    require:'^contextualMenu',
    link: (scope, el, attr, contextualMenuCtrl) => {

      scope.onOptionChange = () => {
        if(scope.promotion.global !== 1) {
          scope.promotion.visible = 0;
          scope.promotion.dialogFlag = 0;
          scope.promotion.displayName = '';
        }
      };
    }
  }
}
