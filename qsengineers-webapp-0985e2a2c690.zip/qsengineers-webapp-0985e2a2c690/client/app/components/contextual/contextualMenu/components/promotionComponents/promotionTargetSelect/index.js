// Import styles
import "./promotionTargetSelect.scss";

// Import internal modules
import controller from './promotionTargetSelect.controller';
import directive from './promotionTargetSelect.directive';
import ChipsAutoComplete from 'app/components/chipsAutocomplete';

export default angular.module("promotionTargetSelect" , [ChipsAutoComplete])

  .controller(controller.UID, controller)
  .directive("promotionTargetSelect", directive)
  .name;
