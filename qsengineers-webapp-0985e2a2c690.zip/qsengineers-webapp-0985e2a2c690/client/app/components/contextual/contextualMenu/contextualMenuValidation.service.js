export default class ContextualMenuValidationService {
  static get UID() {
    return 'ContextualMenuValidationService';
  }

  /*Collection Slot contextual*/
  hasSlotBasicTabErrors (contextualForm, entity) {

    return  contextualForm
            && contextualForm.submitted
            &&
            (
              contextualForm.entityName.$invalid
              || contextualForm.entityDisplayName.$invalid
              || contextualForm.entityEnd.$invalid
              || contextualForm.entityLeadTime.$invalid
            );
  }

  /*Collection Slot contextual*/
  hasSlotAdvancedTabErrors (contextualForm, entity) {

    return  contextualForm
            && contextualForm.submitted
            &&
            (
              contextualForm.entityStart.$invalid
              || (entity.$hasSteps && contextualForm.entityStep.$invalid)
            );
  }

  /*Manager user contextual*/
  hasUserTabErrors (contextualForm, entity) {

    return  contextualForm
            && contextualForm.submitted
            &&
            (
              contextualForm.entityName.$invalid
              || contextualForm.entityEmail.$invalid
            );
  }

  /*Manager user contextual*/
  hasUserVenuesTabErrors (contextualForm, entity) {

    const hasError = contextualForm
            && contextualForm.submitted
            &&
            (
              !entity.venueIds.length &&
              !entity.groupIds.length &&
              !entity.channelId
            );

    return hasError;
  }

  /*Menu Section contextual*/
  hasSectionTabError(contextualForm, entity) {
    return  contextualForm
            && contextualForm.submitted
            &&
            (
              contextualForm.entityName.$invalid
              || contextualForm.entityDescription.$invalid
            );
  }

  /*Menu Section contextual*/
  hasSectionAdvancedTabError(contextualForm, entity) {

    function hasHours() {
      return entity.$sectionHours.filter((hour) => {
        return hour.$open && hour.$close;
      }).length > 0;
    }

    function hasHoursError() {
      return [0, 1, 2, 3, 4, 5, 6].filter((value) => {
        return contextualForm[`openingHourOpen_${value}`].$invalid
            || contextualForm[`openingHourClosed_${value}`].$invalid;
      }).length > 0;
    }

    return  contextualForm
            && contextualForm.submitted
            &&
            (
              entity.scheduledFlag &&
              (!hasHours() || hasHoursError())
            );
  }

  constructor() {
    'ngInject';
  }
}
