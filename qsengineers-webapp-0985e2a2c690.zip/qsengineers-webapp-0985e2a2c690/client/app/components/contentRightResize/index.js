// Import internal modules
import directive from './contentRightResize.directive';

export default angular.module("contentRightResize" , [])

  .directive("contentRightResize", directive)
  .name;
