// Import Style
import './dialog.scss';

// Import modules dependencies
import icons from 'app/components/icons/icons.module';

// Import internal modules
import service from './dialog.service';

export default angular.module('dialog', [icons])
  .service(service.UID, service)
  .name;
