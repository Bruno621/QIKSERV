import menuPublishController from './menuPublish/dialog.menuPublish.controller';

export default class DialogService {

  static get UID(){
    return 'DialogService';
  }

  confirm(title, content, options) {
    const {$rootScope, gettextCatalog} = this;

    function DialogConfirmController($scope, $mdDialog) {
      'ngInject';

      $scope.close = function() {
        if (angular.isFunction($scope.onClose)) {
          $scope.onClose();
        }
        $mdDialog.cancel();
      };

      $scope.cancel = function() {
        if (angular.isFunction($scope.onCancel)) {
          $scope.onCancel();
        }
        $mdDialog.cancel();
      };

      $scope.confirm = function() {
        if (angular.isFunction($scope.onConfirm)) {
          $scope.onConfirm();
        }
        $mdDialog.hide(true);
      };
    }

    const newScope = $rootScope.$new();
    newScope.title = title;
    newScope.content = content;

    options = options || {};
    angular.extend(newScope, options);

    // SET button texts
    newScope.cancelButtonText = newScope.cancelButtonText || gettextCatalog.getString('No');
    newScope.confirmButtonText = newScope.confirmButtonText || gettextCatalog.getString('Yes');

    return this.$mdDialog.show({
      template: require('./dialog.confirm.tpl.html'),
      scope: newScope,
      escapeToClose: false,
      clickOutsideToClose: false,
      controller: DialogConfirmController
    });
  }

  delete (title, content) {

    function DeleteController($scope, $mdDialog) {
      "ngInject";
      $scope.cancel = function() {
        $mdDialog.cancel();
      };
      $scope.confirm = function() {
        $mdDialog.hide(true);
      };
    }
    const newScope = this.$rootScope.$new();
    newScope.title=title;
    newScope.content = content;
    newScope.hasCancel = true;
    return this.$mdDialog.show({
      template:require('./dialog.delete.tpl.html'),
      scope:newScope,
      focusOnOpen:false,
      controller: DeleteController
    });
  }

   retry(title, content) {

    function RetryController($scope, $mdDialog) {
      "ngInject";
      $scope.confirm = function() {
        $mdDialog.hide(true);
      };
    }
    const newScope = this.$rootScope.$new();
    newScope.title=title;
    newScope.content = content;
    newScope.hasCancel = false;
    return this.$mdDialog.show({
      template:require('./dialog.retry.tpl.html'),
      scope:newScope,
      focusOnOpen:false,
      controller: RetryController
    });
  }

  //tittle, content and array of buttons with {text:'confirm', id:1}. id will be returned on promise success
  show (title, content, buttons, options) {

    function DialogController($scope, $mdDialog) {
      "ngInject";
      $scope.cancel = function() {
        $mdDialog.cancel();
      };
      $scope.confirm = function(buttonId) {
        $mdDialog.hide(buttonId);
      };
    }
    const newScope = this.$rootScope.$new();
    newScope.title=title;
    newScope.content = content;
    newScope.buttons = buttons;

    options = options || {};

    angular.extend(newScope, options);
    return this.$mdDialog.show({
      template:require('./dialog.tpl.html'),
      scope:newScope,
      focusOnOpen:false,
      controller: DialogController
    });
  }

  showTextDialog($scope, title, placeholder, titleMessage, buttons, onInput) {

    function DialogController($scope, $mdDialog) {
      "ngInject";

      this.cancel = function() {
        $mdDialog.cancel();
      };
      this.confirm = function(buttonId) {

        if (this.areaForm.$invalid) {
          return;
        }

        $mdDialog.hide(buttonId);
      };
      this.onInput = typeof onInput === 'function' ? onInput : function() {};
    }

    return this.$mdDialog.show({
      template:require('./dialog.text.tpl.html'),
      scope:$scope,
      preserveScope: true,
      focusOnOpen:true,
      escapeToClose: true,
      clickOutsideToClose: true,
      controller: DialogController,
      bindToController: true,
      controllerAs: 'diagCtrl',
      locals: { title: title, placeholder: placeholder, message: titleMessage, buttons: buttons}
    });
  }

  showItemAvailability(data, templateString) {
    const { $rootScope } = this;

    function DialogItemAvaiability($scope, $mdDialog) {
      'ngInject';

      $scope.cancel = () => {
        $mdDialog.cancel();
      };

      $scope.confirm = () => {
        $mdDialog.hide({
          availabilityType: $scope.availabilityType,
          availableDate: $scope.availableDate,
        });
      };

      this.startDate = new Date();
    }

    const newScope = $rootScope.$new();
    angular.extend(newScope, data);

    return this.$mdDialog.show({
      template: templateString,
      scope: newScope,
      preserveScope: true,
      escapeToClose: false,
      clickOutsideToClose: false,
      controller: DialogItemAvaiability,
      controllerAs: 'diagCtrl',
      bindToController: true,
    });
  }

  showPublishMenu(menu) {

    return this.$mdDialog.show({
      template: require('./menuPublish/dialog.menuPublish.tpl.html'),
      escapeToClose: false,
      clickOutsideToClose: false,
      controller: menuPublishController,
      controllerAs: '$menuPublish',
      bindToController: true,
      locals: {
        menu: menu,
      },
    });
  }

  constructor($rootScope, $q, $mdDialog, gettextCatalog) {
    'ngInject';
    this.$rootScope = $rootScope;
    this.$q = $q;
    this.$mdDialog = $mdDialog;
    this.gettextCatalog = gettextCatalog;
  }
}
