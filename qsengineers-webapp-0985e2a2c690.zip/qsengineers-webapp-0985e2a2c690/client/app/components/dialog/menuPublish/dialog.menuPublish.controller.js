export default class menuPublishController {
  static get UID(){
    return "menuPublishController"
  }

  toggleCheckbox (provider) {

    var index = this.selectedProviders.indexOf(provider);

    if (index === -1) {
      this.selectedProviders.push(provider);
    } else {
      this.selectedProviders.splice(index, 1);
    }
  }

  cancel = () => {
    this.$mdDialog.cancel();
  };

  confirm = () => {
    this.$mdDialog.hide({
      selectedProviders: this.selectedProviders.map((provider) => provider.type)
    });
  };

  constructor(StateService, $mdDialog) {
    'ngInject';
    this.$mdDialog = $mdDialog;
    this.selectedProviders = [];

    this.providers = StateService.venue.deliveryServices;
    // this.isFetchingProviders = true;
    // MenuPublishService.getDeliveryProviders()
    //   .then((result) => this.providers = result)
    //   .finally(() => $timeout(() => this.isFetchingProviders = false));
  }
}
