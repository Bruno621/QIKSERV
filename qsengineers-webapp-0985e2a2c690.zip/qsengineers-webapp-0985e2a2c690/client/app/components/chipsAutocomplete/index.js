// Import styles
import "./chipsAutocomplete.scss";

// Import internal modules
import controller from './chipsAutocomplete.controller';
import directive from './chipsAutocomplete.directive';

export default angular.module("chipsAutocomplete" , [])

  .controller(controller.UID, controller)
  .directive("chipsAutocomplete", directive)
  .name;
