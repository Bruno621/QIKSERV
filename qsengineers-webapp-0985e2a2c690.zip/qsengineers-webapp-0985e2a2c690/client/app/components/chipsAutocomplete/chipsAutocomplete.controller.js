export default class chipsAutocompleteController {
  static get UID() {
    return "chipsAutocompleteController"
  }

  handleNotFound(name) {
    console.log('ChipsAutoComplete [handleNotFound] - name', name);
    if (this.onNotFound) {
      return this.onNotFound({
        query: name
      });
    }

    return this.newTag(name);
  }

  addToModel(element) {
    console.log('ChipsAutoComplete [addToModel] - element', element);
    if (!this.checkExists(element, this.ngModel)) {
      this.ngModel.push(element);
    }
  }

  addToCollection(element) {
    console.log('ChipsAutoComplete [addToCollection] - element', element);
    if (!this.checkExists(element, this.collection)) {
      this.collection.push(element);
    }
  }

  checkExists(element, array) {
    console.log('ChipsAutoComplete [checkExists] - element', element);
    const existing = array.find(item => {
      return item.id == element.id;
    });
    return existing;
  }

  transformChip(chip) {
    console.log('ChipsAutoComplete [transformChip] - chip', chip);
    if (!angular.isObject(chip)) {
      this.searchText = chip;
      return null;
    }

    if (this.checkExists(chip, this.ngModel)) {
      return null;
    }

    // we need to clear searchText manually here, because when we add the md-model-options=debounce , its suddenlly stopped to clean the text.
    this.searchText = "";
    return chip;
  }

  clearSelection() {
    console.log('ChipsAutoComplete [clearSelection]');
    this.selectedItem = null;
  }

  clearSearchText() {
    console.log('ChipsAutoComplete [clearSearchText]');
    this.searchText = null;
  }

  constructor(StateService, gettextCatalog) {
    "ngInject";

    this.StateService = StateService;

    this.clearSelection();
    this.clearSearchText();
    this.ngModel = this.ngModel || [];
    this.collection = this.collection || [];
    this.separatorKeys = [13, 188];
  }
}
