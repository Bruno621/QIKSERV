import controller from './chipsAutocomplete.controller'

export default function chipsAutocomplete(){
  "ngInject";
  return {
    restrict: 'E',
    scope: {
      ngModel: "=",
      notFoundText: "=?",
      mdMinLength: "=?",
      placeholder: "=?",
      onSearch: "&?",
      onNotFound: "&?",
    },
    template: require("./chipsAutocomplete.tpl.html"),
    replace: true,
    controller: controller.UID,
    controllerAs: "$chipsAutocomplete",
    bindToController: true,
    link: (scope, el, attr, ctrl) => {

    }
  }
}
