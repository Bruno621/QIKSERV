
import directive from './autoOpenCalendar.directive';

export default angular.module("autoOpenCalendar" , [])

  .directive("autoOpenCalendar", directive)
  .name;
