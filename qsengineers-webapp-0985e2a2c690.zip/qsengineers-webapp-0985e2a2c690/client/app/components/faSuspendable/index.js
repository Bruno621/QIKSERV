
import directive from './faSuspendable.directive';

export default angular.module("faSuspendable" , [])

  .directive("faSuspendable", directive)
  .name;
