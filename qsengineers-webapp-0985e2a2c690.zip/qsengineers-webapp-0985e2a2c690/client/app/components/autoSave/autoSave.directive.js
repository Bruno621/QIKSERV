export default function autoSave(gettextCatalog) {
  'ngInject';

  return {
    restrict: 'E',
    replace: true,
    scope: {
      isSaving: '=',
      isError: '=',
      isFormError: '=',
      formErrorMessage: '=?',
      retry: '&',
    },
    link: postLink,
    template: require('./autoSave.tpl.html')
  };

  function postLink(scope, element, attrs) {
    scope.pristine = true;

    scope.$watch('isSaving', newVal => {
      if (newVal) {
        scope.pristine = false;
      }
    });

    scope.$watch('isFormError', newVal => {
      if (newVal) {
        scope.pristine = false;
      }
    });

    scope.getFormErrorMessage = () => {
      return scope.formErrorMessage || gettextCatalog.getString('Autosave error. Invalid fields.');
    };

    scope.doRetry = () => {
      if (scope.retry) {
        scope.retry();
      }
    };
  }
}
