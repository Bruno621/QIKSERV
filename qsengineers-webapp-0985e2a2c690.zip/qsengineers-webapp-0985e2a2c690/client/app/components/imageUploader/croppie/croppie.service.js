import controller from './croppieDialog.controller';

export default class CroppieService {

  static get UID(){
    return "CroppieService"
  }

  show(src, boundry, vp, output){
    if (!boundry){
      boundry= {w: 700, h:500};
    }
    if (!vp){
      vp={w: 590, h:393};
    }

    return this.$mdDialog.show({
      controller: controller,
      template: require('./croppieDialog.tpl.html'),
      clickOutsideToClose:true,
      bindToController:true,
      controllerAs:'vm',
      onComplete: this.onComplete.bind(this),
      locals:{
        src:src,
        boundry:boundry,
        output:output,
        vp:vp
      }
    });
  }

  onComplete(scope,element, options) {
    console.log('croppie [afterShowAnimation] - ', scope, element, options);
    scope.vm.rendered = true;
  }

  constructor($mdDialog) {
    "ngInject";
    this.$mdDialog = $mdDialog;

  }
}