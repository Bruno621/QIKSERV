// Import Style
import './entitySwitch.scss';

// Import internal modules
import controller from './entitySwitch.controller';
import directive from './entitySwitch.directive';

export default angular.module('entitySwitch' , [])
  .controller(controller.UID, controller)
  .directive('entitySwitch', directive)
  .name;
