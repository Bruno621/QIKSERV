export default class entitySwitchController {
  static get UID() {
    return 'entitySwitchController';
  }

  onToggleChannel(channel) {
    const {selected, groupIds, venueIds} = this;

    if (selected.channelId) {
      selected.channelId = null;
      selected.groupIds = [];
      selected.venueIds = [];
    } else {
      selected.channelId = channel.id;
      selected.groupIds = angular.copy(groupIds);
      selected.venueIds = angular.copy(venueIds);
    }

    this.onToggle && this.onToggle();
  }

  onValidateChannel() {
    const {entities, selected} = this;
    if (entities.venues.length === selected.venueIds.length) {
      selected.channelId = entities.channel.id;
    }
  }

  isChannelSelected() {
    const {channel, selected} = this;
    return angular.isObject(channel) && channel.id === selected.channelId;
  }

  onToggleGroup(venueGroup) {
    const {selected} = this;
    const index = selected.groupIds.indexOf(venueGroup.id);

    if (index === -1) {
      selected.groupIds.push(venueGroup.id);
      const venueIdsToInsert = venueGroup.venueIds.filter(id => {
        return selected.venueIds.indexOf(id) === -1;
      });
      selected.venueIds = selected.venueIds.concat(venueIdsToInsert);
      this.onValidateChannel();
    } else {
      selected.channelId = null;
      selected.venueIds = selected.venueIds.filter(venueId => {
        return venueGroup.venueIds.indexOf(venueId) === -1;
      });
      this.onUpdateGroups();
    }

    this.onToggle && this.onToggle();
  }

  onUpdateGroups() {
    const {entities, selected} = this;
    selected.groupIds = entities.venueGroups.reduce((groupIds, group) => {
      const groupVenueIds = group.venueIds.filter(id => {
        return selected.venueIds.indexOf(id) > -1;
      });

      if (groupVenueIds.length === group.venueIds.length) {
        groupIds.push(group.id);
      }
      return groupIds;
    }, []);
  }

  isGroupSelected(venueGroup) {
    return this.selected.groupIds.indexOf(venueGroup.id) > -1;
  }

  onToggleVenue(venue) {
    const {entities, selected} = this;
    const index = selected.venueIds.indexOf(venue.id);

    if (index === -1) {
      selected.venueIds.push(venue.id);
      this.onUpdateGroups();
      this.onValidateChannel();
    } else {
      selected.venueIds.splice(index, 1);
      selected.channelId = null;

      entities.venueGroups.forEach(venueGroup => {
        if (venueGroup.venueIds.indexOf(venue.id) > -1) {
          const index = selected.groupIds.indexOf(venueGroup.id);
          selected.groupIds.splice(index, 1);
        }
      });
    }

    this.onToggle && this.onToggle();
  }

  isVenueSelected(venue) {
    return this.selected.venueIds.indexOf(venue.id) > -1;
  }

  constructor() {
    'ngInject';
    // Defaults
    this.channel = this.entities.channel;
    this.groupIds = this.entities.venueGroups.map(venueGroup => venueGroup.id);
    this.venueIds = this.entities.venues.map(venue => venue.id);
  }
}
