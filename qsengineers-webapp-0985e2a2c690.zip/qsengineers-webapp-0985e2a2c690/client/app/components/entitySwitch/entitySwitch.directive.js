import controller from './entitySwitch.controller'

export default function entitySwitchDirective() {
  return {
    restrict: 'E',
    controller: controller.UID,
    controllerAs: '$entity',
    bindToController: true,
    scope: {
      entities: '=',
      selected: '=',
      onToggle: '&?'
    },
    template: require('./entitySwitch.tpl.html')
  }
}
