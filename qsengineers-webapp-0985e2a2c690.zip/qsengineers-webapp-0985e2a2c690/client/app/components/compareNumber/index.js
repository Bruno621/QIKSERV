
import directive from './compareNumber.directive';

export default angular.module("compareNumber" , [])

  .directive("compareNumber", directive)
  .name;
