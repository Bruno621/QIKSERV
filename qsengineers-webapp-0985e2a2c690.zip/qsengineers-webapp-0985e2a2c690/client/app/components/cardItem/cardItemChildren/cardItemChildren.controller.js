export default class cardItemChildrenController {
  static get UID(){
    return "cardItemChildrenController"
  }

  /* @ngInject */
  constructor() {
    this.title = "I am a cardItemChildren component"
  }
}
