export default class cardItemChildController {
  static get UID(){
    return 'cardItemChildController';
  }

  onModifierMoved($modifiers, $partFrom, $partTo, $indexFrom, $indexTo) {
    const {ModifierService, Spinner, Snack, gettextCatalog, modifiers, option} = this;
    const LOADER_KEY = 'moving-modifier-option';

    Spinner.show(LOADER_KEY);

    ModifierService.updateModifiersPosition(option, modifiers)
      .then(() => {
        Snack.show(gettextCatalog.getString('Modifiers moved successfully'));

      }, () => {
        Snack.showError(gettextCatalog.getString('Error moving modifiers'));

      }).finally(() => {
        Spinner.hide(LOADER_KEY);
      });
  }

  onNewModifierMoved($modifiers, $partFrom, $partTo, $indexFrom, $indexTo) {

    const {gettextCatalog, ApiErrorCode} = this;

    const parentModifiers = this.parent && this.parent.modifiers ? this.parent.modifiers : null;

    //is Adding to self?
    if ($modifiers.map((m)=>m.id).indexOf(this.option.modifierId)>-1){
      return;
    }

    if (!this.option.id) {
      return;
    }

    //item has modifier?
    if (this.ModifierService.isModifiersDuplicated($modifiers, this.option, parentModifiers)){
      return this.Snack.showError(gettextCatalog.getString("One or more modifiers already in option"));
    }

    //is cyclic reference?
    if (this.ModifierService.canAddModifiers($modifiers, this.modifier)){
      return this.Snack.showError(gettextCatalog.getString("Cannot create cyclic set of modifiers"));
    }

    this.Spinner.show("moving-modifier-option");

    let promise = this.ModifierService.addCustomModifierToParent($modifiers, this.option);

    promise.then((modifiers)=>{

      Array.prototype.push.apply(this.option.modifiers, modifiers);
      Array.prototype.push.apply(this.modifiers, modifiers);

      this.Snack.show(gettextCatalog.getString("Added modifiers to option"));
    },(err)=>{
      if(err.status === 409 && err.errorCode == ApiErrorCode.MODIFIERS_NESTED_CYCLIC) {
        this.Snack.showError(gettextCatalog.getString("Cannot create cyclic set of modifiers"));
      } else {
        this.Snack.showError(gettextCatalog.getString("Error adding modifiers to option"));
      }

    })
    .then(()=>{
      this.Spinner.hide("moving-modifier-option");
    })
  }

  onModifierRemoved (modifier) {

    let index = this.option.modifiers.map((mod) => {

      return mod.id;
    }).indexOf(modifier.id);

    if (index !== -1) {
      this.modifiers.splice(index, 1);
      this.option.modifiers.splice(index, 1);
    }
  }

  buildModifiers () {

    if (!this.option.modifiers) {
      return;
    }

    this.modifiers = this.option.modifiers.map((_modifier, index) => {

      return this.ModifierService.getModifierById(_modifier.id);
    });
  }

  getNotAvailableText(item) {
    const { ModifierService } = this;

    return ModifierService.getNotAvailableText(item);
  }

  constructor($scope, $q, ModifierService, Snack, Spinner, gettextCatalog, APIErrorCode, BroadcastEvents) {
    'ngInject';

    // NG dependencies
    this.$q = $q;

    // Services
    this.ModifierService = ModifierService;
    this.Snack = Snack;
    this.Spinner = Spinner;
    this.gettextCatalog = gettextCatalog;
    this.ApiErrorCode = APIErrorCode;

    // Defaults
    this.modifiers = [];
    this.newModifiers = [];
    this.svRootId = `modifier_option_${this.option.id}`;

    $scope.$watch(() => {

      return this.option.modifiers;
    }, () => {

      this.buildModifiers();
    }, true);

    $scope.$on(BroadcastEvents.ON_DELETE_MODIFIER, (event, modifier) => {

      this.onModifierRemoved(modifier);
    });
  }
}
