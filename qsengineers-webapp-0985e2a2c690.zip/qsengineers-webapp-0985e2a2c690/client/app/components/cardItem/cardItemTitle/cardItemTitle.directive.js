
export default function cardItemTitle($timeout, UtilsService, $window) {
  'ngInject';

  return {
    restrict: 'E',
    template: require('./cardItemTitle.tpl.html'),
    scope: {
      showVisible: '&?',
      hasVisible: '=?',
      showPaused: '&?',
      hasPause: '=?',
      hasFastFood: '=',
      isAlcoholic: '=',
      isComboMainItem: '=?',
      isComboSideItem: '=?',
    },
    replace: true,
    transclude: true,
    require: '^cardItem',
    link: (scope, element, attr, ctrl) => {
      scope.vm = ctrl;

      // this is used to not propagate the click event to parents when the actions is clicked on tablet
      // some parents have click event and do redirects,
      // we dont want those redirects when clicked to open the edit actions in tablet
      scope.openActions = ($event) => {
        $event.preventDefault();
        $event.stopPropagation();
      };

      scope.handleActionsHover = () => {
        const $itemActions = angular.element(element[0].querySelector('.item-actions'));
        $timeout(() => {
          if (!UtilsService.isMobile) {
            // attach this event when is not running on mobile device
            $itemActions.on('mouseenter', (event) => {
              ctrl.toggleCardActions(event);
            });
          } else {
            // attach this event when is running on mobile device to fix problems with hover
            $itemActions.on('mousedown touchstart', (event) => {
              // event.preventDefault();
              // event.stopPropagation();
              ctrl.toggleCardActions(event, true);

              $window.addEventListener('click', function windowEventListener() {
                // when the element clicked is not the itemActions we need to hide the actions like the hover behavior
                if (event.target !== $itemActions) {
                  ctrl.toggleCardActions(event, false);
                  $window.removeEventListener('click', windowEventListener);
                }
              });
            });
          }
        });
      };
    },
  };
}
