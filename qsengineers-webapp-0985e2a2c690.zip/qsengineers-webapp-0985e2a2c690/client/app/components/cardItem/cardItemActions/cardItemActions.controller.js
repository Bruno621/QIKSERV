export default class cardItemActionsController {
  static get UID(){
    return "cardItemActionsController";
  }

  shouldEnableResume() {
    return angular.isUndefined(this.isBlockedForResume) || this.isBlockedForResume;
  }

  shouldShowOnAdd () {

  	return typeof this.isAdd === 'undefined' || this.isAdd;
  }

  shouldShowOnAddCustomField () {

  	return typeof this.isAddCustomField === 'undefined' || this.isAddCustomField;
  }

  shouldShowDelete () {
    return typeof this.showDelete === 'undefined' || this.showDelete;
  }

  shouldShowClone () {
    return typeof this.showClone === 'undefined' || this.showClone;
  }

  shouldShowPublish () {
    return typeof this.showPublish === 'undefined' || this.showPublish;
  }

  shouldShowOutOfStock () {
    return this.showOutOfStock && this.hasStockCreatePermission;
  }

  shouldShowDeliveryAvailability () {
    return this.showOutOfStock && this.hasPushMenuToDeliveryProvider;
  }

  constructor($scope, gettextCatalog, PermissionService, FeatureService, Permissions) {
    'ngInject';

    this.visibleMessage =  this.visibleMessage || gettextCatalog.getString('Hide from menu');
    this.invisibleMessage = this.invisibleMessage || gettextCatalog.getString('Show on menu');
    this.resumeMessage = this.resumeMessage || gettextCatalog.getString('Resume this promotion');
    this.pauseMessage = this.pauseMessage || gettextCatalog.getString('Pause this promotion');

    this.moveMessage = gettextCatalog.getString('Move');
    this.publishMessage = gettextCatalog.getString('Publish to delivery service');
    this.duplicateMessage = gettextCatalog.getString('Duplicate');
    this.deleteMessage = gettextCatalog.getString('Delete');
    this.editMessage = gettextCatalog.getString('Edit');

    this.applyPromotionMessage = gettextCatalog.getString('Apply to a customer account');

    this.externalEventsMessage = gettextCatalog.getString('External events');
    this.customerNotesMessage = gettextCatalog.getString('Customer notes');
    this.placeOrderMessage = gettextCatalog.getString('Place order');
    this.orderHistoryMessage = gettextCatalog.getString('View order history');
    this.lockChannelMessage = gettextCatalog.getString('This item can only be edited at channel level');

    this.hasStockCreatePermission = PermissionService.hasPermission(Permissions.STOCK_MANAGER);
    this.hasPushMenuToDeliveryProvider = FeatureService.hasPushMenuToDeliveryProvider();
  }
}
