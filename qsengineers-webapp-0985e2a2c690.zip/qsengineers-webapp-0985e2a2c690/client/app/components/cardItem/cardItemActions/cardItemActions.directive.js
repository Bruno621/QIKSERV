import controller from './cardItemActions.controller';
export default function cardItemActions($parse, UtilsService){
  "ngInject";

  //will display item actions based on the callbacks set in cardItem.cardItemActions
  // ex: if you pass onClone clone action will be visible, if you don't it'll be hidden
  return {
    restrict: 'E',
    scope: {
      isVisible:"=",
      isPaused:"=?",
      isAdd:"=?",
      isAddCustomField:"=?",
      isAddUser:"=?",
      isExternalEventsVisible: '=?',
      onClone:'&?',
      onPublish:'&?',
      onDelete:'&?',
      onEdit:'&?',
      onVisibility:'&?',
      onPause:'&?',
      onMove:'&?',
      onAdd:'&?',
      onAddCustomField:'&?',
      onAddLocation:'&?',
      onPublishKioskMenu: '&',
      onSync:'&?',
      onAddUser: '&?',
      onNotes: '&?',
      onCart: '&?',
      onHistory: '&?',
      onItemAvailabilityClick: '&?',
      onDeliveryAvailabilityClick: '&?',
      onPublishMenuClick: '&?',
      disableAdd:'=?',
      disableAddCustomField:'=?',
      visibleMessage:'@',
      invisibleMessage:'@',
      resumeMessage: '=?',
      pauseMessage: '=?',
      addMessage: '=?',
      onExternalEvents: '&?',
      addCustomFieldMessage: '=?',
      addLocationMessage: '=?',
      publishKioskMenuMessage: '=?',
      syncMessage: '=?',
      isBlockedForEdit: '=?',
      isBlockedForResume: '=?',
      showDelete: '=?',
      showClone: '=?',
      showPublish: '=?',
      showOutOfStock: '=?',
      showPublishKioskMenu: '=?',
      showSyncMenus: '=?',
    },
    template: require("./cardItemActions.tpl.html"),
    replace:true,
    controller: controller.UID,
    controllerAs: "cardItemActionsCtrl",
    bindToController: true,
    require:["^cardItem", "cardItemActions"],
    link: (scope, element, attrs, ctrls) => {

      scope.cardItem = ctrls[0];

      const $cardActionsLeaveTrap = angular.element(element[0].querySelector('.card-actions-leave-trap'));

      $cardActionsLeaveTrap.on('mouseleave click', (event) => {
        ctrls[0].toggleCardActions(event, false);
      });

      // this is used to not propagate the drag and drop or reorder event
      // to parents when some action is clicked on tablet
      if(UtilsService.isMobile) {
        $cardActionsLeaveTrap.on('mousedown touchstart', (event) => {
          event.preventDefault();
          if(event.type !== 'touchstart') {
            event.stopPropagation();
          }
        })
      }
    }
  };
}
