import controller from './cardItem.controller'

export default function cardItem() {
  'ngInject';
  return {
    restrict: 'E',
    require: 'cardItem',
    replace: true,
    transclude: true,
    controller: controller.UID,
    controllerAs: 'vm',
    bindToController: true,
    scope: {
      hasActions: '=?',
      hiddenActions: '=?',
      item: '=',
      selected: '=?',
      deleted: '=?',
      expanded: '=?'
    },
    template: require('./cardItem.tpl.html'),
    link: (scope, element, attr, ctrl) => {
      element.on('mouseleave', (event) => {
        ctrl.toggleCardActions(event, false);
      });
    }
  };
}
