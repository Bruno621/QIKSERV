export default class cardItemController {
  static get UID(){
    return "cardItemController";
  }

  toggleCardActions($event, newStatus){
    this.showCardActions = newStatus !== undefined ? newStatus : !this.showCardActions;

    if (this.$cardActions) {
      if (this.showCardActions) {
        this.$cardActions.classList.add('active');
      } else {
        this.$cardActions.classList.remove('active');
      }
    }

    $event.stopPropagation();
  }


  constructor($timeout, $element, contextual, contextualMenu, LabelService, Spinner, Snack, ModifierService) {
    "ngInject";

    $timeout(() => {
      const elementClassName = '.' + $element[0].className.split(' ').join('.');
      this.$cardActions = $element[0].querySelector(elementClassName + ' > .card-item-actions md-card-actions');
    })
  }
}
