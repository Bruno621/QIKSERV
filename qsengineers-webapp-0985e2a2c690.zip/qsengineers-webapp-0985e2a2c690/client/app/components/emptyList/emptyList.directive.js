export default function icon(){
    "ngInject";
    return {
      scope: {
        searchText: '=',
        elements: '='
      },
      restrict: 'E',
      template: require("./emptyList.tpl.html"),
      replace:true
    };
  }
  