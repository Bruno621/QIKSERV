// Import Style
import './emptyList.scss';

import directive from './emptyList.directive';

export default angular.module("emptyList" , [])
  .directive("emptyList", directive)
  .name;
