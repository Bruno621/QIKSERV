export default class cardItemListController {
  static get UID(){
    return "cardItemListController"
  }

  onItemCreated(newItem, isLast){
    this.addItemInPosition(newItem, isLast);
    this.deleteItem({});
  }

  onItemUpdated(){
    this.selectItem();
    this.deleteItem({});
  }

  addItemInPosition(item, isLast=false){
    if (this.collection.filter((i)=>i.id===item.id).length)
      return;
    let indexBefore = this.collection.length-1; //force add to last wiht splice(-1,...);
    if (!isLast){
      indexBefore = -1;
      this.collection.forEach((i, index)=>{
        if (i.position <= item.position){
          indexBefore = index;
        }
      })
    }
    this.collection.splice(indexBefore+1, 0, item);
  }

  // add a cloned item in the correct position after the original item
  insert (currentItem, newItem, section) {
    newItem.sectionId = section.id;
    newItem.menuId = section.menuId;
    this.collection.splice(this.collection.indexOf(currentItem) + 1, 0, newItem);
  }

  onUpdateItem(oldItem, newItem) {

    newItem.$show = true;  //need show for animation
    newItem.$selected = false;  //need show for animation

    this.collection.splice(this.collection.indexOf(oldItem), 1, newItem);
  }

  onItemDeleted(item){
    this.deleteItem(item)
  }

  isItemDuplicated(items, qty){
   for (let j=0;j<items.length;j++){
     let found = 0;
      for (let i=0;i<this.collection.length;i++){
        if (this.collection[i].id === items[j].id){
          found++;
          // sort list adds the item in the new list, if we find it we must remove it
          if (found>qty){
            return true;
          }
        }
      }
    }
  }

  expandItem(item) {

    if (this.currentExpandedItem && this.currentExpandedItem.id !== item.id) {
      this.currentExpandedItem.$expanded = false;
    }

    item.$expanded = !!!item.$expanded;

    this.currentExpandedItem = item;
  }

  onSimpleSort(data){
    const promises = [];
    this.collection.forEach((s, index)=>{
      let clone = angular.copy(s);
      clone.position=index*1000;
      promises.push(clone.update(data));
    });
    return this.$q.all(promises)
  }

  onSimpleSortWithoutCopy(data) {
    const promises = [];
    this.collection.forEach((s, index) => {
      // check if the item has an id to prevent try to update an item that is being created in the interface
      // To reproduce it:
      //    Click on the + button in the SectionList (will open the new section view)
      //    Without complete the new section creation, try to move a section position (drag & drop)
      //    Without this condition, it was trying to save a section with no Id,
      //        and was showing an Snack.error, but the others sections were saved
      if (s.id) {
        s.position = index * 1000;
        promises.push(s.update(data));
      }
    });
    return this.$q.all(promises)
  }

  deleteItem(item){
    if (this.collection){
      this.collection = this.collection.filter((s)=>item.id !== s.id);
    }
    //FIXME have to to this twice because of the searchable lists
    if (this.collectionResults){
      this.collectionResults = this.collectionResults.filter((s)=>item.id !== s.id);
    }
  }

  selectItem(item){
    if (this.collection) {
      this.collection.forEach((i)=>{
        if (item && i.id===item.id){
          i.$selected = true;
        } else {
          i.$selected = false
        }
      });
    }
  }

  clickNew(){
    if (this.onClickNew){
      this.onClickNew();
    }
  }

  constructor($scope, $timeout, $q) {
    "ngInject";
    this.$scope = $scope;
    this.$timeout = $timeout;
    this.$q = $q;

    // Add New button position for the Card Item List
    // Items and Modifiers view use it with 'top' potision
    this.addButtonPosition = this.addButtonPosition || 'bottom';
  }
}
