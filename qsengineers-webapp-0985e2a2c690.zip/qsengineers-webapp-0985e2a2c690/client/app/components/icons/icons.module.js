// Icons
import { CloseIconComponent } from './closeIcon/closeIcon.component';

export default angular.module('webapp.icons' , [])
  .component('closeIcon', CloseIconComponent)
  .name;
