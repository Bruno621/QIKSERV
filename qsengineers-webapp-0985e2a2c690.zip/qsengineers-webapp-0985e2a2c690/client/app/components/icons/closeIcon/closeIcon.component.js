export const CloseIconComponent = {
  template: require('./closeIcon.tpl.html'),
};
