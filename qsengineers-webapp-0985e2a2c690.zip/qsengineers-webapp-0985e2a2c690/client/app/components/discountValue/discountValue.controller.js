
export default class DiscountValueController {
  static get UID() {
    return 'DiscountValueController';
  }

  onToggleType() {
    const isFixed = this.type === 'FIXED';

    this.amount = isFixed ? (this.amount * 100) : (this.amount / 100);
    this.maxAmount = isFixed ? null : 0;

    this.onChange && this.onChange();

    if (this.formCtrl.$submitted) {
      this.formCtrl.discountValue.$validate();
    }
  }

  constructor($filter, gettextCatalog) {
    'ngInject';
    // SET label text
    this.label = this.label || gettextCatalog.getString('Discount value');
    // SET input required property
    this.required = angular.isDefined(this.required) ? this.required : true;
    // SET model options
    this.options = this.options || {updateOn: 'default'};

    // SET the error messages
    this.messages = {
      required: gettextCatalog.getString('This is required.'),
      invalidPrice: gettextCatalog.getString('Invalid price.'),
      invalidValue: gettextCatalog.getString('Invalid value.'),
      maxDecimalValue: gettextCatalog.getString('Max value is {{value}}.', {
        value: $filter('currency')('99999999.99', true)
      })
    };
  }
}
