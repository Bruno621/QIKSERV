// Import Style
import './discountValue.scss';

// Import internal modules
import controller from './discountValue.controller';
import directive from './discountValue.directive';

export default angular.module('discountValue' , [])
  .controller(controller.UID, controller)
  .directive('discountValue', directive)
  .name;
