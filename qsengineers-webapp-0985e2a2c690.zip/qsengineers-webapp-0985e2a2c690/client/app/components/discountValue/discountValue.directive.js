
import controller from './discountValue.controller';

export default function discountValue() {
  return {
    restrict: 'E',
    replace: true,
    scope: {
      label: '@?',
      formCtrl: '=ngFormCtrl',
      type: '=ngModelType',
      amount: '=ngModelAmount',
      maxAmount: '=ngModelMaxAmount',
      options: '=?ngModelOptions',
      required: '=?ngRequired',
      onChange: '&?ngModelChange',
    },
    bindToController: true,
    controller: controller.UID,
    controllerAs: '$ctrl',
    template: require('./discountValue.tpl.html'),
  };
}
