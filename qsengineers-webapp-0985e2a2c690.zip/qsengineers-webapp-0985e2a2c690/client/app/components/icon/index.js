// Import Style

import directive from './icon.directive';

export default angular.module("icon" , [])
  .directive("icon", directive)
  .name;
