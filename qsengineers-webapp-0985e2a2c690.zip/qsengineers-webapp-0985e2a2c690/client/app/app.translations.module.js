
// Vendor
import gettext from 'angular-gettext';

// Translations
import translations from './app.translations.json';

export default angular.module('translations', [gettext])
  .run((gettextCatalog) => {
    // Set all the translations in the gettext
    // TODO: Change it to load only the translations that we need.
    // Eg: load only en-gb
    angular.forEach(translations, (translationObj, translationKey) => {
      gettextCatalog.setStrings(translationKey, translationObj);
    });
  })
  .name;
