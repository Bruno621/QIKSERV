
export default function run($rootScope, $window, Spinner, DucksLoaderService) {
  'ngInject';

  Preoday.Api.headers({
    'preo-appid': $window._release
  });

  Preoday.Settings.loadConfig()
    .then(appConfig => {
      DucksLoaderService.dispatchSettingsAction('setAppConfig', appConfig);
    });

  Preoday.QPSProvider.loadProviders();

  $rootScope.$on('$viewContentLoaded', Spinner.hideInitialSpinner.bind(Spinner));
}
