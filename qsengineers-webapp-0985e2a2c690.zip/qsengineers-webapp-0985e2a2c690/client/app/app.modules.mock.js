[
  'webapp.outlets',
  'webapp.bookings',
  'webapp.events',
  'webapp.venueSettings',
  'webapp.vouchers',
  'webapp.menus',
  'webapp.notifications',
  'webapp.payments',
  'webapp.promotions',
  'webapp.manageUsers',
  'webapp.analytics',
  'webapp.styling',
  'webapp.channelPayments',
  'webapp.channelServices',
  'webapp.channelVenues',
  'webapp.loyaltySettings',
  'webapp.manageGroups',
  'webapp.operationalSettings',
  'webapp.deliveryServices',
  'webapp.orderCapacity',
  'webapp.openingHours',
  'webapp.orders',
  'webapp.employees',
  'webapp.users',
  'webapp.taxes',
  'webapp.updateExternalMenus',
  'webapp.customTags',
  'webapp.customers',
  'webapp.legal',
  'webapp.qikservePayments',
  'webapp.loyalty'
].forEach(function (item) {

  try {
    angular.module(item);
  } catch(err) {
    angular.module(item,[]);
  }
});
