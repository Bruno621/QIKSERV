// Import Style
import './app.scss';

import mocks from './app.modules.mock';

// node_modules and bower_components are pre-loaded by webpack
import PreodayServices from './shared/services';

// Import Hooks
import requireAuthHook from './config/hooks/requireAuth.hook';

// Import base modules
import run from './app.run';
import routes from './app.routes';

//old base
import constants from './app.constants';
import config from './app.config';
import translations from './app.translations.module';
import dialog from './components/dialog';
import icon from './components/icon';
import snack from './components/snack';
import spinner from './components/spinner';
import fullSpinner from './components/fullSpinner';
import tagList from './components/tagList';
import itemChips from './components/itemChips';
import breadcrumb from './components/breadcrumb';
import faSuspendable from './components/faSuspendable';
import faParentSuspendable from './components/faParentSuspendable';
import refresher from './components/refresher';
import autoSave from './components/autoSave';
import milesOrKms from './components/milesOrKms';
import inlineCalendar from './components/inlineCalendar';
import entitySwitch from './components/entitySwitch';
import discountValue from './components/discountValue';
import emptyList from './components/emptyList';
import pathLine from './components/pathLine';

// Import internal modules
import v2Main from './features/main';
import v2Error from './features/error';
import v2Auth from './features/auth';
import v2NotFound from './features/notFound';
import v2EmailSuccess from './features/emailSuccess';
import v2StripeSuccess from './features/stripeSuccess';
import v2Redirect from './features/redirect';

// Import global components
import imageUploader from './components/imageUploader';
import contextual from './components/contextual';

// SET the current app version
window._release = '@@RELEASE_VERSION';

require('./sentry.config.js');

//TODO convert this to ES6
require('./components/sticky/sticky.directive.js');

  angular.module('webapp', [
  /* external */
  'webapp.vendors',
  'ngRaven',
  /* directives */
  'sticky',
  imageUploader,
  icon,
  tagList,
  itemChips,
  dialog,
  contextual,
  snack,
  spinner,
  fullSpinner,
  breadcrumb,
  autoSave,
  faSuspendable,
  faParentSuspendable,
  refresher,
  milesOrKms,
  inlineCalendar,
  entitySwitch,
  discountValue,
  emptyList,
  pathLine,
  // /* internal */
  constants,
  translations,
  /* Global services */
  PreodayServices,
  /* Base Features */
  v2Main,
  v2Error,
  v2Auth,
  v2NotFound,
  v2EmailSuccess,
  v2StripeSuccess,
  v2Redirect
  ])
  .config(config)
  .run(run)
  .run(requireAuthHook)
  .config(routes)
  .name;

  (function _init(){
    let v2 = document.getElementById("webappv2");
    angular.bootstrap( v2, ['webapp']);
  })()
