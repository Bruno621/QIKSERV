import BroadcastEvents from './app.broadcastEvents.constants';
import EventScheduleFrequency from './shared/constants/app.eventScheduleFrequency.constant';
import APIErrorCode from './shared/constants/app.apiErrorCode.constants';
import ReportTypes from './shared/constants/app.reportTypes.constants';
import VenueImageType from './shared/constants/app.venueImageType.constants';
import PaymentType from './shared/constants/app.paymentType.constants';
import UserRole from './shared/constants/userRole.constants';
import SocialMedia from './shared/constants/app.socialMediaType.constants';
import EventPreorder from './shared/constants/app.eventPreorderOpenType.constants';
import PromotionTarget from './shared/constants/promotionTarget.constants';
import RefundType from './shared/constants/app.refundType.constants';
import PaymentProvidersType from './shared/constants/paymentProvidersType.constants';
import OrderStatus from './shared/constants/orderStatus.constants';
import LocalizedDateFormat from './shared/constants/localizedDateFormat.constants';
import DocumentType from './shared/constants/documentType.constants';

export default angular.module('webapp.constants', [])
  .constant('BroadcastEvents', BroadcastEvents)
  .constant('EventScheduleFrequency', EventScheduleFrequency)
  .constant('APIErrorCode', APIErrorCode)
  .constant('ReportTypes', ReportTypes)
  .constant('VenueImageType', VenueImageType)
  .constant('PaymentType', PaymentType)
  .constant('UserRole', UserRole)
  .constant('SocialMedia', SocialMedia)
  .constant('EventPreorderOpenType', EventPreorder)
  .constant('PromotionTarget', PromotionTarget)
  .constant('RefundType', RefundType)
  .constant('PaymentProvidersType', PaymentProvidersType)
  .constant('OrderStatus', OrderStatus)
  .constant('LocalizedDateFormat', LocalizedDateFormat)
  .constant('DocumentType', DocumentType)
  .name;
